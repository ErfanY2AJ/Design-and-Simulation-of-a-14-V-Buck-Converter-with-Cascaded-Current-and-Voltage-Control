"""Apply Markdown math compatibility and report-figure placement fixes."""
from pathlib import Path
import json
import re

FIGURES = json.loads(Path(__file__).with_name("figure_sources.json").read_text())
FENCE = chr(96) * 3
NOTE = (
    "**Displaying the figures:** Keep this README and the complete "
    + chr(96) + "figures" + chr(96)
    + " directory together. When publishing the project, upload the Markdown "
    "file and that directory with their relative paths preserved. Uploading "
    "only the Markdown file cannot display the bundled image files. "
    "Figure numbers below follow README reading order; each caption also "
    "identifies its source figure and page in the supplied PDF report.\n\n"
)

def prepare_readme(text):
    # Preserve the exact contents of every executable/quoted fenced block.
    expression = r"(^" + FENCE + r"[^\n]*\n.*?^" + FENCE + r"[ \t]*$)"
    parts = re.split(expression, text, flags=re.M | re.S)
    for i in range(0, len(parts), 2):
        parts[i] = re.sub(r"\\operatorname\s*\{", lambda _: r"\mathrm{", parts[i])
    text = "".join(parts)

    heading = "### How to use the files\n\n"
    if NOTE not in text:
        if heading not in text:
            raise ValueError("Expected usage section is missing.")
        text = text.replace(heading, heading + NOTE, 1)

    # The periodic switched traces belong next to the switched-model method.
    pattern = r"!\[[^\]]*\]\(figures/switching_ripple\.png\)"
    image = re.search(pattern, text)
    anchor = '<a id="step-17"></a>'
    if image is None or anchor not in text:
        raise ValueError("Expected ripple image or load-step anchor is missing.")
    if image.start() > text.index(anchor):
        image_text = image.group()
        text = text[:image.start()] + text[image.end():]
        text = text.replace(anchor, image_text + "\n\n" + anchor, 1)

    count = 0
    def decorate(match):
        nonlocal count
        name = match.group(1)
        if name not in FIGURES:
            raise ValueError("Unrecognized report figure: " + name)
        count += 1
        meta = FIGURES[name]
        caption = f"Figure {count}. {meta['caption']}"
        image_text = f"![{caption}](figures/{name})"
        marker = "<!-- readme-figure:" + name + " -->"
        if marker in text:
            return image_text
        return (
            image_text + "\n\n" + marker + "\n\n*"
            + caption
            + f" Source: report Figure {meta['source_figure']}, "
            + f"page {meta['source_page']}.*"
        )
    text = re.sub(r"!\[[^\]]*\]\(figures/([^)\n]+\.png)\)", decorate, text)
    if count != 8:
        raise ValueError(f"Expected 8 report figures, found {count}.")
    return text
