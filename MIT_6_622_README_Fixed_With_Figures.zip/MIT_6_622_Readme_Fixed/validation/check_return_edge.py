"""44 V pulse return-edge verification, including MOSFET body diode.

The overvoltage inhibit stays latched throughout the pulse and return.
The linear filter scan covers 80 widths from 1 us to 1 ms. Selected hybrid
checks also include current from the output back through the MOSFET body diode
when the input filter undershoots below the charged output.
"""
from verify_solution import P,op,cache,prop_many,phase,nodes,csvsave,ROOT,saves
from dataclasses import replace
import numpy as np,itertools,json
import matplotlib.pyplot as plt

def inhibited_rhs(x,p,vg,R):
 vb,vo,_,_=nodes(x,p,R,0)
 if x[3]<-1e-10 or (x[3]<=1e-10 and vo>vb+1.0):
  f=phase(x,p,vg,R,1)
  vb,vo,_,_=nodes(x,p,R,1)
  f[3]=(vb+1.0-p.rl*x[3]-vo)/p.L
  return f,1
 f=phase(x,p,vg,R,0)
 if x[3]<=0 and f[3]<0:f[3]=0
 return f,0

def hybrid(p,vg0,W,width,dt=.5e-6):
 R=196/W;x,_=op(p,vg0,R);x=x[:5];n=round((width+.0012)/dt)
 stats=[0.,0.,0.,0.,np.inf,0.,0.];wave=[];Ed=0
 for k in range(n+1):
  t=k*dt;vg=44. if t<width-1e-12 else vg0
  f,q=inhibited_rhs(x,p,vg,R);vb,vo,_,icd=nodes(x,p,R,q)
  Bi=p.Lf*x[0]/(p.Nf*p.Amin);Bo=p.L*x[3]/(p.N*p.Amin)
  stats[0]=max(stats[0],abs(x[0]));stats[1]=max(stats[1],abs(Bi));stats[2]=max(stats[2],abs(Bo));stats[3]=max(stats[3],vb);stats[4]=min(stats[4],vb);stats[5]=max(stats[5],p.rd*icd**2);stats[6]=max(stats[6],max(-x[3],0))
  Ed+=p.rd*icd**2*dt
  if k%4==0:wave.append([t,vg,vb,x[0],x[3],vo,Bi,Bo,icd])
  old=x[3];a=f;b=inhibited_rhs(x+dt*a/2,p,vg,R)[0];c=inhibited_rhs(x+dt*b/2,p,vg,R)[0];d=inhibited_rhs(x+dt*c,p,vg,R)[0]
  x+=dt*(a+2*b+2*c+d)/6
  if old*x[3]<0:x[3]=0.
 return stats+[Ed],np.array(wave)

def main():
 p=P();linear=[];hy=[];best=None;worst=0
 for sg in itertools.product([-1,1],repeat=3):
  pp=replace(p,Cf=p.Cf*(1+.1*sg[0]),Cd=p.Cd*(1+.1*sg[0]),Lf=p.Lf*(1+.05*sg[1]),rd=p.rd*(1+.1*sg[2]))
  for vg in [24,36]:
   for W in [50,125]:
    R=196/W;x,_=op(pp,vg,R);x=x[:5];c1=cache(pp,44,R,0);c0=cache(pp,vg,R,0)
    for width in np.geomspace(1e-6,1e-3,80):
     a=prop_many(c1,x,np.linspace(0,width,200));b=prop_many(c0,a[-1],np.linspace(0,.0012,400))
     im=max(np.max(abs(a[:,0])),np.max(abs(b[:,0])));B=pp.Lf*im/(pp.Nf*pp.Amin)
     linear.append([*sg,vg,W,width,im,B])
    for width in [.00005,.0001,.000134,.0002]:
     st,wave=hybrid(pp,vg,W,width)
     hy.append([*sg,vg,W,width]+st)
     if st[1]>worst:worst=st[1];best=wave
  print('RETURN_EDGE_GROUP',sg,flush=True)
 csvsave('surge_return_linear_scan.csv','C_sign,Lf_sign,Rd_sign,Vin_initial_V,P_initial_W,pulse_width_s,If_abs_peak_A,Binput_abs_peak_T',linear)
 csvsave('surge_return_hybrid.csv','C_sign,Lf_sign,Rd_sign,Vin_initial_V,P_initial_W,pulse_width_s,If_abs_peak_A,Binput_abs_peak_T,Boutput_abs_peak_T,Vbus_max_V,Vbus_min_V,Rd_peak_W,body_diode_peak_A,Rd_energy_J',hy)
 csvsave('surge_return_worst_waveform.csv','time_s,Vsource_V,Vbus_V,If_A,IL_A,Vo_V,Binput_T,Boutput_T,Icd_A',best)
 hy=np.array(hy);ss={'linear_cases':len(linear),'hybrid_cases':len(hy),'linear_Binput_max':max(np.array(linear)[:,-1]),'hybrid_Binput_max':max(hy[:,7]),'hybrid_Boutput_max':max(hy[:,8]),'If_abs_peak':max(hy[:,6]),'Vbus_max':max(hy[:,9]),'Vbus_min':min(hy[:,10]),'Rd_peak_W':max(hy[:,11]),'body_diode_peak_A':max(hy[:,12]),'Rd_energy_J':max(hy[:,13])}
 print('RETURN_SUMMARY',ss,flush=True)
 (ROOT/'results'/'surge_return_summary.json').write_text(json.dumps(ss,indent=2))
 assert ss['hybrid_Binput_max']<.3 and ss['hybrid_Boutput_max']<.3
 fig,ax=plt.subplots(3,1,figsize=(9,7),sharex=True)
 t=best[:,0]*1e3
 ax[0].plot(t,best[:,2],label='Filtered bus');ax[0].plot(t,best[:,1],'--',label='Source');ax[0].set(ylabel='Voltage (V)');ax[0].legend(fontsize=10,ncol=2)
 ax[1].plot(t,best[:,3],label='Input inductor');ax[1].plot(t,best[:,4],label='Output inductor');ax[1].set(ylabel='Current (A)');ax[1].legend(fontsize=10,ncol=2)
 ax[2].plot(t,best[:,6],label='Input core');ax[2].plot(t,best[:,7],label='Output core');ax[2].axhline(.3,c='r',ls='--');ax[2].axhline(-.3,c='r',ls='--');ax[2].set(ylabel='Local core flux (T)',xlabel='Time (ms)');ax[2].legend(fontsize=10,ncol=2)
 for a in ax:a.grid(alpha=.2)
 saves(fig,'surge_return_edge')
 convergence()

def convergence():
 tab=np.genfromtxt(ROOT/'results'/'surge_return_hybrid.csv',delimiter=',',skip_header=1)
 row=tab[np.argmax(tab[:,7])];p=P()
 pp=replace(p,Cf=p.Cf*(1+.1*row[0]),Cd=p.Cd*(1+.1*row[0]),Lf=p.Lf*(1+.05*row[1]),rd=p.rd*(1+.1*row[2]))
 rows=[]
 for dt in [.5e-6,.25e-6,.125e-6]:
  st,_=hybrid(pp,row[3],row[4],row[5],dt)
  rows.append([dt,st[0],st[1],st[6],st[7]])
 csvsave('surge_return_step_convergence.csv','time_step_s,If_abs_peak_A,Binput_abs_peak_T,body_diode_peak_A,Rd_energy_J',rows)
 assert (max(np.array(rows)[:,2])-min(np.array(rows)[:,2]))/max(np.array(rows)[:,2])<.01
 print('RETURN_STEP_CONVERGENCE',rows,flush=True)

if __name__=='__main__':main()
