"""Independent numerical evaluation of the equations in matlab/buck622.m.

This file actually ran in Python. It is not evidence of MATLAB execution.
Requires numpy, scipy, matplotlib. Run from any working directory.
"""
from pathlib import Path
from dataclasses import dataclass,replace,asdict
import csv,json,itertools,sys
import numpy as np
from scipy.optimize import brentq
from scipy.linalg import expm
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results';FIG=ROOT/'figures'
OUT.mkdir(exist_ok=True);FIG.mkdir(exist_ok=True)
FONT=Path('/workspace/scratch/d6e7ab363f76/tmp/proposal-review/fonts/times.ttf')
if FONT.exists():
 font_manager.fontManager.addfont(str(FONT))
 plt.rcParams['font.family']=font_manager.FontProperties(fname=str(FONT)).get_name()
plt.rcParams.update({'font.size':12,'axes.labelsize':12,'axes.titlesize':12,'figure.dpi':140,'savefig.dpi':220,'axes.spines.right':False,'axes.spines.top':False})
COLORS=['#145c9e','#de6c29','#248978','#a33d67']

@dataclass
class P:
 V:float=14.;fs:float=1e5;L:float=96.8e-6;Lf:float=48.4e-6
 C:float=2e-3;Cf:float=22e-6;Cd:float=20e-6
 ro:float=.01;rf:float=.005;rd:float=1.5
 rl:float=.020;rlf:float=.043;ron:float=.014;vd:float=1.
 kc:float=2.;kp:float=2.5;ki:float=1250.;aw:float=2000.;ilim:float=10.;dmax:float=.9
 Ta:float=50.;tr:float=36e-9;tf:float=21e-9;Qg:float=100e-9;Vgate:float=10.;Coss:float=1500e-12
 Rhs:float=5.3;Rcs:float=1.;Rjc_mos:float=1.;Rjc_diode:float=.9
 N:int=22;Nf:int=32;AL:float=200e-9;ALf:float=48.4e-6/32**2
 Ae:float=198e-6;Amin:float=168e-6;Aw:float=112e-6;Vcore_cm3:float=13.9
 lesl_in:float=5e-9;lesl_out:float=10e-9;lesl_d:float=20e-9

def op(p,vg,R):
 I=p.V/R;rb=1/(1/p.rf+1/p.rd)
 d=brentq(lambda d:d*(vg-p.rlf*d*I-(p.ron+rb*(1-d))*I)-(1-d)*p.vd-p.rl*I-p.V,0,p.dmax,xtol=1e-14)
 ib=d*I;vb=vg-p.rlf*ib;z=I+(d*(vg+p.vd)-p.V-p.vd)/p.kc
 return np.array([ib,vb,vb,I,p.V,z]),d

def nodes(x,p,R,q):
 G=1/p.rf+1/p.rd
 vb=(x[0]-q*x[3]+x[1]/p.rf+x[2]/p.rd)/G
 vo=(x[4]+p.ro*x[3])/(1+p.ro/R)
 return vb,vo,(vb-x[1])/p.rf,(vb-x[2])/p.rd

def phase(x,p,vg,R,q):
 vb,vo,icf,icd=nodes(x,p,R,q)
 return np.array([(vg-p.rlf*x[0]-vb)/p.Lf,icf/p.Cf,icd/p.Cd,
  (q*(vb-p.ron*x[3])-(1-q)*p.vd-p.rl*x[3]-vo)/p.L,(x[3]-vo/R)/p.C])

def plant(x,p,vg,R,d):
 return d*phase(x,p,vg,R,1)+(1-d)*phase(x,p,vg,R,0)

def controller(x,p,vg,R,limited=True):
 vo=(x[4]+p.ro*x[3])/(1+p.ro/R);e=p.V-vo
 raw=p.kp*e+x[5];ir=np.clip(raw,0,p.ilim) if limited else raw
 dr=(vo+p.vd+p.kc*(ir-x[3]))/(vg+p.vd)
 d=np.clip(dr,0,p.dmax) if limited else dr
 dz=p.ki*e+p.aw*(ir-raw)
 if limited and ((dr>p.dmax and e>0) or (dr<0 and e<0)):dz=p.aw*(ir-raw)
 return d,dz

def closed(x,p,vg,R):
 d,dz=controller(x,p,vg,R,False)
 return np.r_[plant(x[:5],p,vg,R,d),dz]

def jac(fun,x):
 h=1e-20
 return np.column_stack([np.imag(fun(x.astype(complex)+1j*h*np.eye(len(x))[j]))/h for j in range(len(x))])

def outer_loop(p,vg,R,f):
 x,d=op(p,vg,R);Ap=jac(lambda y:plant(y,p,vg,R,d),x[:5]);Bp=phase(x[:5],p,vg,R,1)-phase(x[:5],p,vg,R,0)
 Cy=np.array([0,0,0,p.ro,1.])/(1+p.ro/R);K=Cy.copy();K[3]-=p.kc;K/=vg+p.vd
 Ai=Ap+np.outer(Bp,K);Bi=Bp*p.kc/(vg+p.vd)
 ss=1j*2*np.pi*np.asarray(f)
 H=np.array([Cy@np.linalg.solve(s*np.eye(5)-Ai,Bi) for s in ss])
 return (p.kp+p.ki/ss)*H

def margins(f,L):
 db=20*np.log10(abs(L));ph=np.unwrap(np.angle(L))*180/np.pi;lf=np.log10(f);fc=np.nan;pm=np.nan;gm=np.inf
 for j in np.where((db[:-1]>=0)&(db[1:]<0))[0]:
  a=-db[j]/(db[j+1]-db[j]);pmj=180+ph[j]+a*(ph[j+1]-ph[j])
  if np.isnan(pm) or pmj<pm:pm=pmj;fc=10**(lf[j]+a*(lf[j+1]-lf[j]))
 for j in np.where((ph[:-1]>-180)&(ph[1:]<=-180))[0]:
  a=(-180-ph[j])/(ph[j+1]-ph[j]);gm=min(gm,-db[j]-a*(db[j+1]-db[j]))
 return fc,pm,gm

def stability(p,vg,R,margin=False):
 x,d=op(p,vg,R);A=jac(lambda y:closed(y,p,vg,R),x)
 Ap=jac(lambda y:plant(y,p,vg,R,d),x[:5]);Bp=phase(x[:5],p,vg,R,1)-phase(x[:5],p,vg,R,0)
 K=jac(lambda y:np.array([controller(y,p,vg,R,False)[0]]),x).ravel()
 Cy=np.array([0,0,0,p.ro,1.])/(1+p.ro/R)
 aug=np.zeros((6,6));aug[:5,:5]=Ap;aug[:5,5]=Bp;E=expm(aug/p.fs)
 M=np.zeros((7,7));M[:5,:5]=E[:5,:5];M[:5,6]=E[:5,5];M[5,:5]=-p.ki/p.fs*Cy;M[5,5]=1;M[6,:6]=K
 s={'A':A,'M':M,'poles':np.linalg.eigvals(A),'rho':max(abs(np.linalg.eigvals(M)))}
 s['max_real']=max(s['poles'].real)
 if margin:
  f=np.logspace(0,4.5,3000);L=outer_loop(p,vg,R,f);s['fc'],s['pm'],s['gm']=margins(f,L);s['f']=f;s['loop']=L
 return s

def analytic(p,vg,W,switch_factor=1):
 R=p.V**2/W;x,d=op(p,vg,R);I=p.V/R;vb=vg-p.rlf*x[0]
 di=(p.V+p.vd+p.rl*I)*(1-d)/(p.L*p.fs);rms2=I**2+di**2/12
 a={'D':d,'deltaI':di,'Imin':I-di/2,'Imax':I+di/2}
 a['Pcond']=d*rms2*p.ron;a['Psw']=.5*vb*I*(p.tr+p.tf)*p.fs*switch_factor
 a['Pcoss']=.5*p.Coss*vb**2*p.fs;a['Pgate']=p.Qg*p.Vgate*p.fs
 a['Pmos']=a['Pcond']+a['Psw']+a['Pcoss'];a['Pdiode']=p.vd*(1-d)*I
 a['Pcu']=p.rl*rms2+p.rlf*(d*I)**2
 Icin2=I**2*d*(1-d)+d*di**2/12;a['Pcap']=p.rf*Icin2+p.ro*di**2/12
 Bac=p.L*di/(2*p.N*p.Ae)
 a['Pcore']=1e-3*2.5e-4*p.fs**1.63*Bac**2.45*p.Vcore_cm3
 a.update(Paux=.5,Pleak=.2,Pdamp=.15)
 a['Ploss']=sum(a[k] for k in ['Pmos','Pgate','Pdiode','Pcu','Pcap','Paux','Pleak','Pdamp'])+2*a['Pcore']
 a['eta']=W/(W+a['Ploss']);a['Icin']=np.sqrt(Icin2);a['Icout']=di/np.sqrt(12)
 a['Bpk']=p.L*(I+di/2)/(p.N*p.Amin)
 a['Tmos']=p.Ta+a['Pmos']*(p.Rjc_mos+p.Rcs+p.Rhs)
 a['Tdiode']=p.Ta+(a['Pdiode']+a['Pleak'])*(p.Rjc_diode+p.Rcs+p.Rhs)
 return a

def cache(p,vg,R,q):
 A=jac(lambda y:phase(y,p,vg,R,q),np.zeros(5));b=phase(np.zeros(5),p,vg,R,q)
 lam,V=np.linalg.eig(A);Vi=np.linalg.inv(V);xeq=-np.linalg.solve(A,b)
 return lam,V,Vi,xeq

def prop(c,x,t):
 lam,V,Vi,xeq=c
 return np.real(V@(np.exp(lam*t)*(Vi@(x-xeq)))+xeq)

def prop_many(c,x,t):
 lam,V,Vi,xeq=c
 return np.real((V@(np.exp(np.outer(lam,t))*(Vi@(x-xeq))[:,None])).T+xeq)

def switching(p,vg,Pa,Pb,tstep=.010,tend=.030,ns=12):
 Ts=1/p.fs;nc=round(tend/Ts);x,dhold=op(p,vg,p.V**2/Pa);z=x[5];x=x[:5]
 nper=2*(ns+1);T=np.zeros(nc*nper);X=np.zeros((len(T),5));VO=T.copy();DQ=T.copy();Q=T.copy()
 Rold=None;idx=0
 for k in range(nc):
  t0=k*Ts;W=Pa if t0<tstep-1e-12 else Pb;R=p.V**2/W
  if R!=Rold:cs=[cache(p,vg,R,1),cache(p,vg,R,0)];Rold=R
  dn,dz=controller(np.r_[x,z],p,vg,R,True);z+=Ts*dz
  durations=[dhold*Ts,(1-dhold)*Ts];base=t0
  for m,(c,duration,q) in enumerate(zip(cs,durations,[1,0])):
   th=np.linspace(0,duration,ns+1);xs=prop_many(c,x,th)
   sl=slice(idx,idx+ns+1);T[sl]=base+th;X[sl]=xs;VO[sl]=(xs[:,4]+p.ro*xs[:,3])/(1+p.ro/R);DQ[sl]=dhold;Q[sl]=q
   idx+=ns+1;x=xs[-1].copy();base+=duration
  dhold=dn
 return dict(t=T,x=X,vo=VO,d=DQ,q=Q,vg=vg,Pa=Pa,Pb=Pb)

def harmonic(p,vg,W,N=256):
 a=analytic(p,vg,W);D=a['D'];di=a['deltaI'];I=W/p.V;n=np.arange(1,N+1);kk=1j*2*np.pi*n;w=2*np.pi*p.fs*n
 J=(I-di/2)*(1-np.exp(-kk*D))/kk+di/D*((1-np.exp(-kk*D))/kk**2-D*np.exp(-kk*D)/kk)
 Zf=p.rf+1j*w*p.lesl_in+1/(1j*w*p.Cf);Zd=p.rd+1j*w*p.lesl_d+1/(1j*w*p.Cd)
 Zp=1/(1/Zf+1/Zd);Zs=p.rlf+1j*w*p.Lf
 Is=J*Zp/(Zs+Zp);Vb=-J*(Zp*Zs)/(Zp+Zs);Icf=Vb/Zf;Icd=Vb/Zd
 IL=di*(1-np.exp(-kk*D))/(kk**2*D*(1-D));Zo=p.ro+1j*w*p.lesl_out+1/(1j*w*p.C)
 Vo=IL*Zo/(1+Zo/(p.V**2/W));theta=np.arange(4096)/4096
 basis=np.exp(np.outer(kk,theta));iss=2*np.real(Is@basis);vv=2*np.real(Vo@basis)
 return dict(vo_pp=np.ptp(vv),is_pp=np.ptp(iss),Icf_rms=np.sqrt(2*np.sum(abs(Icf)**2)),Icd_rms=np.sqrt(2*np.sum(abs(Icd)**2)),Vbus_ac_rms=np.sqrt(2*np.sum(abs(Vb)**2)))

def surge(p,vg0=24,W=125,dt=.2e-6,stress=True):
 pp=replace(p,Cf=p.Cf*1.1,Cd=p.Cd*1.1,Lf=p.Lf*1.05) if stress else p
 R=p.V**2/W;x,_=op(pp,vg0,R);x=x[:5];tt=np.arange(round(.001/dt)+1)*dt;S=np.zeros((len(tt),8))
 def rhs(x):
  f=phase(x,pp,44.,R,0)
  if x[3]<=0 and f[3]<0:f[3]=0
  return f
 for k,t in enumerate(tt):
  vb,vo,_,_=nodes(x,pp,R,0);S[k]=[t,44,x[0],vb,x[3],vo,pp.Lf*x[0]/(p.Nf*p.Amin),pp.L*x[3]/(p.N*p.Amin)]
  a=rhs(x);b=rhs(x+dt*a/2);c=rhs(x+dt*b/2);d=rhs(x+dt*c)
  x+=dt*(a+2*b+2*c+d)/6;x[3]=max(x[3],0)
 return S

def csvsave(name,header,rows):
 with (OUT/name).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(header.split(','));w.writerows(rows)

def settle(t,y,target=14,tol=.01):
 bad=np.where(abs(y-target)>tol*target)[0]
 return 0 if not len(bad) else (np.nan if bad[-1]==len(y)-1 else t[bad[-1]+1])

def saves(fig,name):
 fig.tight_layout();fig.savefig(FIG/(name+'.png'),bbox_inches='tight');fig.savefig(FIG/(name+'.pdf'),bbox_inches='tight');plt.close(fig)

def main():
 p=P();corners=[(24,50),(24,125),(36,50),(36,125)];summary={'parameters':asdict(p),'execution':'Python 3 / NumPy / SciPy; MATLAB and Octave not available'}
 rows=[];lin=[];steady=[];ST=[]
 for vg,W in corners:
  a=analytic(p,vg,W);s=stability(p,vg,p.V**2/W,True);sw=switching(p,vg,W,W);steady.append(sw);ST.append(s)
  tail=sw['t']>=.0298;mean=np.trapezoid(sw['vo'][tail],sw['t'][tail])/(sw['t'][tail][-1]-sw['t'][tail][0])
  rows.append([vg,W,a['D'],a['deltaI'],a['Imin'],a['Imax'],a['eta'],a['Ploss'],a['Pmos'],a['Pdiode'],a['Tmos'],a['Tdiode'],np.ptp(sw['vo'][tail]),np.ptp(sw['x'][tail,0]),mean,max(abs(s['poles']))])
  lin.append([vg,W,s['max_real'],s['rho'],s['fc'],s['pm'],s['gm']]);print('CORNER',vg,W,rows[-1],lin[-1],flush=True)
  assert min(sw['x'][:,3])>0,'CCM assumption failed in switched steady run'
 csvsave('corner_results.csv','Vin_V,P_W,D,IL_pp_A,IL_min_A,IL_max_A,efficiency,loss_W,MOS_W,diode_W,Tj_MOS_C,Tj_diode_C,Vo_pp_V,Is_pp_A,Vo_mean_V,max_abs_pole',rows)
 csvsave('stability_corners.csv','Vin_V,P_W,max_real_pole_1_s,sampled_spectral_radius,outer_fc_Hz,outer_PM_deg,outer_GM_dB',lin)
 summary['corners']=rows;summary['stability']=lin
 losscols=['Pcond','Psw','Pcoss','Pgate','Pdiode','Pcu','Pcap','Pcore','Paux','Pleak','Pdamp','Ploss','eta','Icin','Icout','Bpk']
 csvsave('loss_breakdown.csv','Vin_V,P_W,'+','.join(losscols),[[vg,W]+[analytic(p,vg,W)[k] for k in losscols] for vg,W in corners])

 steps=[];stepstats=[]
 for vg in [24,36]:
  for Pa,Pb in [(50,125),(125,50)]:
   sw=switching(p,vg,Pa,Pb);steps.append(sw);n=sw['t']>=.010
   row=[vg,Pa,Pb,min(sw['vo'][n]),max(sw['vo'][n]),max(sw['x'][n,3]),settle(sw['t'][n]-.01,sw['vo'][n])];stepstats.append(row);print('STEP',row,flush=True)
   csvsave(f'load_waveform_{vg}V_{Pa}_{Pb}W.csv','time_s,Vo_V,IL_A,If_A,duty',np.c_[sw['t'][::26],sw['vo'][::26],sw['x'][::26,3],sw['x'][::26,0],sw['d'][::26]])
 csvsave('load_steps.csv','Vin_V,P_before_W,P_after_W,Vo_min_V,Vo_max_V,IL_peak_A,settling_1pct_s',stepstats);summary['load_steps']=stepstats

 grid=[]
 for vg in np.linspace(24,36,13):
  for W in np.linspace(50,125,16):
   a=analytic(p,vg,W);s=stability(p,vg,p.V**2/W);grid.append([vg,W,a['eta'],s['max_real'],s['rho']])
 csvsave('operating_grid.csv','Vin_V,P_W,efficiency,max_real_pole_1_s,sampled_spectral_radius',grid)
 tol=[]
 for bits in range(128):
  signs=2*((bits>>np.arange(7))&1)-1
  pp=replace(p,L=p.L*(1+.05*signs[0]),Lf=p.Lf*(1+.05*signs[1]),C=p.C*(1+.2*signs[2]),Cf=p.Cf*(1+.1*signs[3]),Cd=p.Cd*(1+.1*signs[3]),ro=p.ro*(2.25+1.75*signs[4]),rf=p.rf*(1.25+.75*signs[5]),rd=p.rd*(1+.1*signs[6]))
  for vg,W in corners:
   s=stability(pp,vg,p.V**2/W);tol.append([len(tol)+1,vg,W,pp.L,pp.Lf,pp.C,pp.Cf,pp.Cd,pp.ro,pp.rf,pp.rd,s['max_real'],s['rho']])
 rng=np.random.RandomState(622)
 for k in range(500):
  u=rng.rand(11);pp=replace(p,L=p.L*(.95+.1*u[0]),Lf=p.Lf*(.95+.1*u[1]),C=p.C*(.8+.4*u[2]),Cf=p.Cf*(.9+.2*u[3]),Cd=p.Cd*(.9+.2*u[4]),ro=p.ro*(.5+3.5*u[5]),rf=p.rf*(.5+1.5*u[6]),rd=p.rd*(.9+.2*u[7]))
  vg=24+12*u[8];W=50+75*u[9];s=stability(pp,vg,p.V**2/W)
  tol.append([len(tol)+1,vg,W,pp.L,pp.Lf,pp.C,pp.Cf,pp.Cd,pp.ro,pp.rf,pp.rd,s['max_real'],s['rho']])
 csvsave('tolerance_stability.csv','case,Vin_V,P_W,L_H,Lf_H,C_F,Cf_F,Cd_F,ESRo_ohm,ESRf_ohm,Rd_ohm,max_real_pole_1_s,sampled_spectral_radius',tol)
 tol=np.array(tol);summary['tolerances']={'n':len(tol),'max_real_pole':float(max(tol[:,-2])),'max_sampled_radius':float(max(tol[:,-1]))};print('TOLERANCE',summary['tolerances'],flush=True)

 # Tolerance load steps: all extremes of L, Cout and ESRo, both line endpoints.
 ts=[]
 for sL,sC,sr in itertools.product([-1,1],repeat=3):
  pp=replace(p,L=p.L*(1+.05*sL),C=p.C*(1+.2*sC),ro=p.ro*(2.25+1.75*sr))
  for vg in [24,36]:
   for Pa,Pb in [(50,125),(125,50)]:
    R0=p.V**2/Pa;R1=p.V**2/Pb;x,_=op(pp,vg,R0)
    def limited(t,x):
     d,dz=controller(x,pp,vg,R1,True);return np.r_[plant(x[:5],pp,vg,R1,d),dz]
    sol=solve_ivp(limited,(0,.02),x,rtol=2e-8,atol=1e-9,max_step=1e-5)
    vo=(sol.y[4]+pp.ro*sol.y[3])/(1+pp.ro/R1)
    ts.append([sL,sC,sr,vg,Pa,Pb,min(vo),max(vo),max(sol.y[3])])
 csvsave('tolerance_load_steps_averaged.csv','L_sign,C_sign,ESR_sign,Vin_V,P_before_W,P_after_W,Vo_min_V,Vo_max_V,IL_peak_A',ts)
 summary['tolerance_transients']={'n':len(ts),'vmin':float(min(np.array(ts)[:,6])),'vmax':float(max(np.array(ts)[:,7]))}

 S=surge(p);csvsave('surge_waveforms.csv','time_s,Vsource_V,If_A,Vbus_V,IL_A,Vo_V,Binput_T,Boutput_T',S)
 # Check both input endpoints and load endpoints, with L/C/filter Rd extremes.
 sr=[]
 for csign,lsign,rsign in itertools.product([-1,1],repeat=3):
  pp=replace(p,Cf=p.Cf*(1+.1*csign),Cd=p.Cd*(1+.1*csign),Lf=p.Lf*(1+.05*lsign),rd=p.rd*(1+.1*rsign))
  for vg in [24,36]:
   for W in [50,125]:
    ss=surge(pp,vg,W,dt=.5e-6,stress=False)
    sr.append([csign,lsign,rsign,vg,W,max(ss[:,3]),max(abs(ss[:,2])),max(abs(ss[:,6])),max(abs(ss[:,7]))])
 csvsave('surge_tolerance.csv','C_sign,Lf_sign,Rd_sign,Vin_initial_V,P_initial_W,Vbus_peak_V,If_peak_A,Binput_peak_T,Boutput_peak_T',sr)
 summary['surge']={'vbus_max':float(max(np.array(sr)[:,5])),'if_max':float(max(np.array(sr)[:,6])),'Binput_max':float(max(np.array(sr)[:,7])),'Boutput_max':float(max(np.array(sr)[:,8]))};print('SURGE',summary['surge'],flush=True)

 harms=[]
 for cold in [False,True]:
  pp=replace(p,ro=.04,C=.0016,Cf=.9*p.Cf,Lf=.95*p.Lf) if cold else p
  for vg,W in corners:
   h=harmonic(pp,vg,W);harms.append([int(cold),vg,W,h['vo_pp'],h['is_pp'],h['Icf_rms'],h['Icd_rms'],h['Vbus_ac_rms']])
 csvsave('harmonic_ripple.csv','cold_stress,Vin_V,P_W,Vo_pp_with_ESL_V,Is_pp_with_ESL_A,Icf_rms_A,Icd_rms_A,Vbus_ac_rms_V',harms);summary['harmonics']=harms
 stress=[[vg,W,analytic(replace(p,vd=1.1),vg,W,2)['eta'],analytic(replace(p,vd=1.1),vg,W,2)['Ploss']] for vg,W in corners]
 csvsave('loss_sensitivity.csv','Vin_V,P_W,efficiency_2x_switching_1p1V_diode,loss_W',stress);summary['loss_sensitivity']=stress
 summary['efficiency_grid_min']=float(min(np.array(grid)[:,2]));summary['switch_vo_pp_max']=float(max(np.array(rows)[:,12]));summary['switch_is_pp_max']=float(max(np.array(rows)[:,13]));summary['static_mean_error_max']=float(max(abs(np.array(rows)[:,14]-14)))
 summary['harmonic_vo_pp_max']=float(max(np.array(harms)[:,3]));summary['harmonic_is_pp_max']=float(max(np.array(harms)[:,4]))
 # Consistency: equilibrium residuals, analytical Jacobians, exact integrator.
 checks=[]
 for vg,W in corners:
  x,d=op(p,vg,p.V**2/W);res=max(abs(closed(x,p,vg,p.V**2/W)))
  c=cache(p,vg,p.V**2/W,1);xe=prop(c,x[:5],3e-6)
  rr=solve_ivp(lambda t,y:phase(y,p,vg,p.V**2/W,1),(0,3e-6),x[:5],rtol=1e-11,atol=1e-12).y[:,-1]
  checks.append([vg,W,res,max(abs(xe-rr))])
 csvsave('numerical_consistency.csv','Vin_V,P_W,equilibrium_rhs_norm,exact_vs_ODE_state_error',checks)
 convergence=[]
 for N in [128,256,512]:
  h=harmonic(replace(p,ro=.04,C=.0016,Cf=.9*p.Cf,Lf=.95*p.Lf),36,125,N)
  convergence.append([N,h['vo_pp'],h['is_pp']])
 csvsave('harmonic_convergence.csv','N_harmonics,Vo_pp_V,Is_pp_A',convergence)

 # Honest compliance assertions apply to the stated models and parameter sets.
 assert min(np.array(rows)[:,6])>=.9
 assert summary['switch_vo_pp_max']<=.1 and summary['switch_is_pp_max']<=.05
 assert min(np.array(stepstats)[:,3])>=11.2 and max(np.array(stepstats)[:,4])<=16.8
 assert summary['tolerances']['max_real_pole']<0 and summary['tolerances']['max_sampled_radius']<1
 assert summary['surge']['Binput_max']<.3 and summary['surge']['Boutput_max']<.3
 assert summary['harmonic_vo_pp_max']<.1 and summary['harmonic_is_pp_max']<.05
 assert max(np.array(rows)[:,10])<150 and max(np.array(rows)[:,11])<150
 (OUT/'summary.json').write_text(json.dumps(summary,indent=2))
 print('SUMMARY',json.dumps(summary,indent=2),flush=True)

 fig,ax=plt.subplots(2,2,figsize=(10,6),sharex=True,sharey=True)
 for a,s,c in zip(ax.ravel(),steps,COLORS):
  a.plot(s['t']*1e3,s['vo'],color=c,lw=1.2);a.axhline(11.2,color='#b24342',ls='--',lw=.7);a.axhline(16.8,color='#b24342',ls='--',lw=.7);a.axhline(14,color='.6',ls=':',lw=.7)
  a.set_title(f"{s['vg']} V input; {s['Pa']} to {s['Pb']} W");a.set(xlim=(8,23),ylim=(10.9,17.1),xlabel='Time (ms)',ylabel='Output voltage (V)');a.grid(alpha=.2)
 saves(fig,'load_steps')
 fig,ax=plt.subplots(2,1,figsize=(9,5.8),sharex=True)
 for s,c,(vg,W) in zip(steady,COLORS,corners):
  n=s['t']>.02995;t=(s['t'][n]-.02995)*1e6
  ax[0].plot(t,1000*(s['vo'][n]-14),color=c,lw=.9,label=f'{vg} V, {W} W')
  mean=np.trapezoid(s['x'][n,0],s['t'][n])/(s['t'][n][-1]-s['t'][n][0]);ax[1].plot(t,1e3*(s['x'][n,0]-mean),color=c,lw=.9)
 ax[0].set(ylabel='Output minus 14 V (mV)');ax[0].legend(ncol=2,fontsize=10)
 ax[1].set(xlabel='Time (us)',ylabel='Source current AC (mA)')
 for a in ax:a.grid(alpha=.2)
 saves(fig,'switching_ripple')
 fig,ax=plt.subplots(2,1,figsize=(9,5.8),sharex=True)
 for s,c,(vg,W) in zip(ST,COLORS,corners):
  ax[0].semilogx(s['f'],20*np.log10(abs(s['loop'])),c=c,label=f'{vg} V, {W} W');ax[1].semilogx(s['f'],np.unwrap(np.angle(s['loop']))*180/np.pi,c=c)
 ax[0].axhline(0,c='.5',lw=.7);ax[0].set(ylabel='Outer-loop gain (dB)',ylim=(-60,45));ax[0].legend(fontsize=10,ncol=2)
 ax[1].axhline(-180,c='.5',lw=.7);ax[1].set(xlabel='Frequency (Hz)',ylabel='Phase (deg)',ylim=(-280,0))
 for a in ax:a.grid(which='both',alpha=.18)
 saves(fig,'outer_loop_bode')
 fig,ax=plt.subplots(3,1,figsize=(9,7),sharex=True)
 ax[0].plot(S[:,0]*1e3,S[:,3],color=COLORS[0]);ax[0].axhline(100,color='.4',ls='--');ax[0].set(ylabel='Input bus (V)',ylim=(0,105))
 ax[1].plot(S[:,0]*1e3,S[:,2],color=COLORS[1]);ax[1].set(ylabel='Source current (A)')
 ax[2].plot(S[:,0]*1e3,S[:,6],label='Input inductor',color=COLORS[2]);ax[2].plot(S[:,0]*1e3,S[:,7],label='Output inductor',color=COLORS[3]);ax[2].axhline(.3,color='.4',ls='--');ax[2].axhline(-.3,color='.4',ls='--');ax[2].set(ylabel='Peak-section flux (T)',xlabel='Time in 44 V pulse (ms)');ax[2].legend(fontsize=10)
 for a in ax:a.grid(alpha=.2)
 saves(fig,'input_surge')
 fig,ax=plt.subplots(1,2,figsize=(10,4))
 gg=np.array(grid);A=gg[:,2].reshape(13,16)*100
 im=ax[0].imshow(A,origin='lower',aspect='auto',extent=[50,125,24,36],cmap='viridis',vmin=90,vmax=96);ax[0].set(xlabel='Output power (W)',ylabel='Input voltage (V)',title='Estimated efficiency (%)');fig.colorbar(im,ax=ax[0])
 ax[1].scatter(tol[:,-2],tol[:,-1],s=8,alpha=.4,c=COLORS[0]);ax[1].axhline(1,c='r',ls='--');ax[1].set(xlabel='Largest real continuous pole (1/s)',ylabel='Sampled spectral radius',title=f'{len(tol)} tolerance cases');ax[1].grid(alpha=.2)
 saves(fig,'efficiency_and_stability')

if __name__=='__main__':main()
