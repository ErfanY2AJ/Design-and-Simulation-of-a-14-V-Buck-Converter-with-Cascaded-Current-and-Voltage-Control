"""Check source ripple at interior Vin, where D(1-D) can be largest."""
from verify_solution import P,harmonic,csvsave,ROOT
from dataclasses import replace
import numpy as np,json

def main():
 p=P();rows=[]
 for cold in [False,True]:
  pp=replace(p,ro=.04,C=.0016,Cf=.9*p.Cf,Lf=.95*p.Lf) if cold else p
  for vg in np.linspace(24,36,25):
   for W in [50,125]:
    h=harmonic(pp,vg,W,256);rows.append([int(cold),vg,W,h['vo_pp'],h['is_pp']])
 csvsave('harmonic_line_sweep.csv','cold_stress,Vin_V,P_W,Vo_pp_with_ESL_V,Is_pp_with_ESL_A',rows)
 a=np.array(rows);summary={'cases':len(a),'max_output_ripple_V':max(a[:,3]),'max_source_ripple_A':max(a[:,4]),'source_worst_case':a[np.argmax(a[:,4])].tolist()}
 (ROOT/'results'/'harmonic_line_summary.json').write_text(json.dumps(summary,indent=2));print(summary)
 assert summary['max_source_ripple_A']<.05 and summary['max_output_ripple_V']<.1

if __name__=='__main__':main()
