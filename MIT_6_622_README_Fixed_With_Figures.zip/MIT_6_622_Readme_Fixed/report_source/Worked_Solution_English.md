MIT 6.622 Power Electronics - Design Project

Worked Design, MATLAB Code, and Independent Numerical Verification

14 V asynchronous buck converter | Prepared for Erfan Yavari | 8 November 2026

| Element | Selected design |
| --- | --- |
| Power stage | 100 kHz; STP110N10F7 MOSFET; STPS20100CT dual diode, anodes paralleled. |
| Output inductor | 96.8 µH: RM14/I, 3F3, 22 turns, custom A<sub>L</sub> = 200 nH/turn²; 38 × 0.25 mm strands. |
| Input inductor | 48.4 µH: RM14/I, 3F3, 32 turns, custom A<sub>L</sub> = 47.265625 nH/turn²; 26 × 0.25 mm strands. |
| Capacitors / damping | C<sub>o</sub>: 2 × 1000 µF / 25 V Panasonic FR. C<sub>f</sub>: 10 × 2.2 µF / 100 V WIMA MKP4. C<sub>d</sub>: 2 × 10 µF / 100 V MKP4; R<sub>d</sub> = 1.5 Ω / 5 W. |
| Cooling / control | Two separate SK 129 50.8 STS heatsinks, 5.3 °C/W each. Voltage PI: 2.5 + 1250/s A/V; inner current gain: 2 Ω. |
| Input protection | 40 V latched switching inhibit; 44 V pulse survival is checked with switching disabled. |

| Requirement | Predicted result |
| --- | --- |
| Static output: 14 V ± 3% | Largest simulated mean error: 4.67 mV. |
| Load-step bounds: 11.2-16.8 V | 12.708-15.418 V, switched nominal cases. |
| Output ripple ≤ 100 mV p-p | 40.55 mV, ESR/ESL stress model. |
| Source ripple ≤ 50 mA p-p | 29.61 mA, ESR/ESL stress line sweep. |
| Efficiency ≥ 90% | Minimum estimate 92.63%; loss stress 91.66%. |
| Thermal / magnetic limits | T<sub>j</sub> ≤ 89.13 °C at 50 °C ambient; core flux ≤ 0.256 T in tested cases. |

Results are conditional on the stated component and parasitic assumptions. The numerical model was executed in Python; the supplied MATLAB source was syntax-checked but was not executed in MATLAB or Octave.


## 1. Problem interpretation and design boundaries

The supplied assignment [1] requires a buck converter operating from 24-36 V, delivering 50-125 W to a resistive load at 14 V. The steady-state tolerance is ±3%, the permitted output ripple is 100 mV peak-to-peak, and the input current ripple measured at an ideal source must remain below 50 mA peak-to-peak. The converter must survive a 44 V input pulse lasting up to 1 ms. Operation during that exceptional pulse is explicitly optional.

The output limits are therefore obtained directly by multiplying the nominal output voltage by the permitted relative deviations:

$$V_{o,\mathrm{static}}\in[14(0.97),14(1.03)]=[13.58,14.42]\ \mathrm{V}$$

$$V_{o,\mathrm{step}}\in[14(0.80),14(1.20)]=[11.2,16.8]\ \mathrm{V}$$

For a resistive load, power is the square of voltage divided by resistance. Hence, the two specified power endpoints correspond to the following resistance and current values. These resistances are retained during each load-step simulation; a constant-power load is not substituted.

$$R=\frac{V_o^2}{P_o},\qquad I_o=\frac{V_o}{R}=\frac{P_o}{V_o}$$

| Nominal output power | Load resistance | Output current |
| --- | --- | --- |
| 50 W | 3.920 Ω | 3.571 A |
| 125 W | 1.568 Ω | 8.929 A |

The power stage uses a high-side N-channel MOSFET, a freewheel Schottky diode, a custom output inductor, and an output capacitor bank. A separate, damped LC input filter suppresses the pulsating current drawn by the buck switch. No pre-wound inductor, packaged EMI filter, or converter module is used. The operating mode is continuous conduction at both load endpoints.

The assignment mentions 40 °C for heatsink sizing although the stated operating range extends to 50 °C. This solution uses 50 °C for thermal calculations. Gate-drive circuit design and the physical PWM modulator are outside the assignment; nevertheless, their approximate power consumption and a full-cycle digital delay are included in the calculations. A current sensor is required by the selected control law.

All reported simulations are model calculations, not laboratory measurements. Component datasheets accompany the solution. Cold-temperature ESR, package interconnect inductance, and leakage assumptions are distinguished from manufacturer-guaranteed limits in Sections 7 and 15.


## 2. Circuit and signal definitions

Figure 1. Power-stage and filter connections. The diode cathode is connected to the switch node. The input filter capacitor is located after Lf; its ripple current must not be confused with the current at the ideal source.

Vg is the ideal source voltage, vb is the filtered input-bus voltage, vo is the load terminal voltage, if is the input-inductor current, and iL is the output-inductor current. The switching variable q equals one during the MOSFET ON interval and zero during the freewheel interval. The duty ratio D is the fraction of a switching period for which q = 1.

$$T_s=\frac{1}{f_s}=10\ \mu\mathrm{s},\qquad D=\frac{t_{\mathrm{on}}}{T_s},\qquad f_s=100\ \mathrm{kHz}$$

Figure 2. Cascade voltage/current feedback, feedforward terms, current-reference limit, digital delay, and overvoltage inhibit. The diagram describes the implemented mathematical controller.

The source-voltage feedforward term uses Vg, measured upstream of the input filter. It does not assume that the instantaneous, rippling bus voltage equals Vg. The difference between these voltages, and the resulting interaction with the controller, is retained in the complete model.


## 3. Buck-converter equations derived from the two switch positions

Start with the inductor constitutive relation: voltage equals inductance multiplied by the rate of change of current. Apply Kirchhoff’s voltage law around the power path while the MOSFET is ON. The switch contributes an on-resistance RQ and the output winding contributes resistance rL:

$$v_L=L\frac{di_L}{dt},\qquad L\frac{di_L}{dt}=v_b-v_o-(r_L+R_Q)i_L\quad(q=1)$$

When the MOSFET is OFF, the inductor current continues through the diode. The diode anode is at ground and its cathode is at approximately -VF. The inductor voltage is consequently negative:

$$L\frac{di_L}{dt}=-V_F-v_o-r_Li_L\quad(q=0)$$

In periodic steady state, the current at the end of a switching period equals the current at its beginning. Integrating the inductor voltage over that period therefore gives zero. With small ripple, replace iL and vo in each interval by their average values. The result is the volt-second balance condition:

$$D\left[V_b-V_o-(r_L+R_Q)I_o\right]+(1-D)\left[-V_F-V_o-r_LI_o\right]=0$$

Collect the terms containing D and solve for the duty ratio:

$$D=\frac{V_o+V_F+r_LI_o}{V_b+V_F-R_QI_o}$$

For an ideal switch and diode, rL = RQ = VF = 0; the expression reduces to D = Vo/Vb. The actual design uses the nonideal expression and then solves the more accurate equilibrium of the input filter, including capacitor ESR. That solution is a one-dimensional root calculation, not a fitted empirical duty curve.

$$D\left[V_g-r_fDI_o-R_QI_o-r_b(1-D)I_o\right]-(1-D)V_F-r_LI_o-V_o=0$$

$$r_b=\left(\frac{1}{r_{Cf}}+\frac{1}{R_d}\right)^{-1}$$

Here rf denotes the input-inductor winding resistance, not the capacitor ESR rCf. The small term rb(1-D)Io accounts for the lower input-bus voltage while the switch is actually conducting. It appears because switch current and bus voltage are correlated. Averaging their product as the product of their averages would omit this loss.

| Vg | Po | Computed duty D |
| --- | --- | --- |
| 24 V | 50 W | 0.606500 |
| 24 V | 125 W | 0.616483 |
| 36 V | 50 W | 0.408698 |
| 36 V | 125 W | 0.413697 |


## 4. Output-inductor design and continuous-conduction check

Within each interval the inductor voltage is approximately constant, so the current changes linearly. Multiply the OFF-state current slope by the OFF duration. The resulting decrease in current equals the ON-state increase in periodic steady state:

$$\Delta I_L=\frac{(V_o+V_F+r_LI_o)(1-D)T_s}{L}$$

Selecting L = 96.8 µH limits the calculated current ripple to approximately 0.61 A at 24 V and 0.92 A at 36 V. This is small relative to the minimum load current of 3.571 A. A smaller ripple reduces output-capacitor ripple and MOSFET peak current, at the cost of a larger magnetic component and a slower current slope.

$$I_{L,\min}=I_o-\frac{\Delta I_L}{2},\qquad I_{L,\max}=I_o+\frac{\Delta I_L}{2}$$

The minimum current stays positive in all nominal corners; the smallest computed value is 3.111 A. Thus the CCM assumption used for normal operation is internally consistent. The switched trajectories also remain in CCM throughout the specified load steps.

To derive the RMS current, write the inductor current as a DC component plus a zero-mean triangular component. The cross term integrates to zero. For a triangular waveform whose peak-to-peak amplitude is ΔIL, direct integration of its squared value gives ΔIL²/12:

$$I_{L,\mathrm{rms}}^2=\frac{1}{T_s}\int_0^{T_s}(I_o+\widetilde i_L)^2dt=I_o^2+\frac{\Delta I_L^2}{12}$$

This RMS value, rather than the average current alone, is used in winding, MOSFET, and capacitor loss calculations. At the upper load endpoint it is approximately 8.933 A.

| Input / output power | ΔIL | IL,min / IL,max |
| --- | --- | --- |
| 24 V / 50 W | 0.613 A | 3.265 / 3.878 A |
| 24 V / 125 W | 0.601 A | 8.628 / 9.229 A |
| 36 V / 50 W | 0.921 A | 3.111 / 4.032 A |
| 36 V / 125 W | 0.919 A | 8.469 / 9.388 A |


## 5. Custom magnetic components: turns, gap, wire, and temperature

Both inductors use the Ferroxcube RM14/I geometry in 3F3 material [4], with effective area Ae = 198 mm², minimum local area Amin = 168 mm², core volume 13.9 cm³, mean turn length 71 mm, and bobbin winding area Aw = 112 mm². The minimum area is used for saturation checks; the effective area is used for AC flux and loss estimates.

A gapped core is characterized by its inductance factor AL. Inductance increases with the square of the number of turns. Use 22 turns for the output inductor and 32 turns for the input inductor. The larger input turn count accommodates current reversal after a short input pulse. The selected targets are:

$$L=A_LN^2=(200\ \mathrm{nH})(22)^2=96.8\ \mu\mathrm{H}$$

$$L_f=A_{L,f}N_f^2=(47.265625\ \mathrm{nH})(32)^2=48.4\ \mu\mathrm{H}$$

These AL values are custom gapping targets, not claimed standard catalog part numbers. Start from an RM14/I-3F3 core set and adjust the gap until the assembled inductance factor meets the target. A ±5% inductance range is used in the tolerance analysis. The first-order magnetic-circuit estimate below neglects fringing and the ferrite reluctance; it gives an effective total gap of approximately 1.24 mm for AL = 200 nH and 5.26 mm for AL = 47.265625 nH.

$$A_L\simeq\frac{\mu_0 A_e}{g},\qquad g_{\mathrm{eff}}\simeq\frac{\mu_0 A_e}{A_L}$$

The computed effective gap must not be copied directly as a mechanical grinding depth. The manufacturer’s existing RM14/I gapping table already illustrates the influence of geometry and fringing. Final inductance must be measured on the assembled core, including the winding and clamping arrangement.

Flux linkage is NΦ = Li, and magnetic flux density is flux divided by cross-sectional area. These definitions give the saturation check:

$$B_{\mathrm{pk}}=\frac{LI_{\mathrm{pk}}}{NA_{\min}},\qquad B_{\mathrm{ac,pk}}=\frac{L\Delta I_L}{2NA_e}$$

The largest steady-state output flux is approximately 0.246 T. In the tested averaged load-transient tolerance cases, the largest output-core flux is 0.256 T. Input-filter pulse-return cases, including MOSFET body-diode conduction, reach 0.245 T. All are below the assignment’s 0.3 T limit. This does not authorize using the components beyond the tested current range.

Use parallel, individually insulated 0.25 mm diameter copper strands: 38 strands in the output winding and 26 strands in the input winding. Interleave or transpose the strands as practical; the intent is a custom stranded winding, not an unspecified catalog inductor.

$$A_{\mathrm{Cu}}=n_s\frac{\pi d_s^2}{4},\qquad J=\frac{I_{\mathrm{rms}}}{A_{\mathrm{Cu}}},\qquad k_u=\frac{NA_{\mathrm{Cu}}}{A_w}$$

| Winding | Copper area | Current density / fill |
| --- | --- | --- |
| Output: 22 turns | 1.865 mm² | 4.79 A/mm² / 36.6% |
| Input: 32 turns | 1.276 mm² | about 4.32 A/mm² / 36.5% |

The assignment’s limit of 500 A/cm² equals 5 A/mm². The output winding therefore passes with limited margin; wire insulation and bobbin clearances must be included when building the winding. Both copper fill fractions are below the selected 40% winding-window allowance. The output winding requires about 102.6 mm² of window at that allowance, leaving about 9.4 mm² for additional geometric clearance. Keep copper away from the gap where practical.

These current-density values refer to normal RMS operation. The short input-return transient has a larger instantaneous current density; its winding heating is assessed by pulse energy, while saturation is checked with the instantaneous peak current. The enlarged input turn count is retained even though normal switching ripple alone would allow fewer turns.

$$R_{\mathrm{Cu}}(T)=\rho_{20}\frac{N\ell_{\mathrm{turn}}}{A_{\mathrm{Cu}}}\left[1+0.00393(T-20)\right]$$

With copper resistivity 1.724 × 10⁻⁸ Ω m, the approximate 100 °C resistances are 19.0 mΩ and 40.3 mΩ before extra lead allowance. The electrical model uses 20 mΩ and 43 mΩ. This hot-resistance choice is conservative relative to the predicted winding temperatures.

For the optional core-loss estimate, use the assignment’s 100-300 kHz fit and retain its specified units. The factor 10⁻³ converts the resulting milliwatts to watts:

$$P_{\mathrm{core}}[\mathrm{W}]=10^{-3}(2.5\times10^{-4})f_s^{1.63}B_{\mathrm{ac,pk}}^{2.45}V_{\mathrm{core}}[\mathrm{cm}^3]$$

$$P_{\mathrm{Cu}}=R_{\mathrm{Cu}}I_{\mathrm{rms}}^2,\qquad \Delta T_{\mathrm{core}}\simeq19(P_{\mathrm{Cu}}+P_{\mathrm{core}})$$

The output copper loss is about 1.60 W at full load; its core-loss estimate is below 7 mW. Using the assignment’s 19 °C/W RM14 thermal resistance gives approximately 81 °C at a 50 °C ambient. The input winding is approximately 75 °C at its largest normal DC current. These are crude estimates; proximity loss, gap-fringing loss, and detailed airflow are not modeled. The 0.25 mm strand diameter is below twice the approximately 0.21 mm copper skin depth at 100 kHz, which limits individual-strand skin effect.


## 6. Output capacitor: capacitance, ESR, ESL, and ripple current

The output capacitor carries the difference between inductor current and load current. In periodic steady state the DC components cancel, leaving the triangular current ripple:

$$i_{Co}=i_L-\frac{v_o}{R},\qquad I_{Co,\mathrm{rms}}=\frac{\Delta I_L}{\sqrt{12}}$$

Capacitor charge is the time integral of capacitor current. Over the interval between the minimum and maximum capacitor voltage, the positive area is a triangle with height ΔIL/2 and total base Ts/2. Therefore the charge increase is ΔILTs/8, and dividing by capacitance gives the capacitive ripple:

$$\Delta Q=\frac{1}{2}\frac{\Delta I_L}{2}\frac{T_s}{2}=\frac{\Delta I_LT_s}{8},\qquad \Delta V_C=\frac{\Delta I_L}{8f_sC_o}$$

ESR creates an additional voltage proportional to capacitor current. A conservative sum of the capacitive and ESR peak-to-peak contributions is:

$$\Delta V_{o,\mathrm{pp}}\lesssim\frac{\Delta I_L}{8f_sC_o}+r_o\Delta I_L$$

Select two Panasonic EEUFR1E102 capacitors in parallel: each is 1000 µF, 25 V, and rated for 2.18 A RMS at 100 kHz [5]. The series datasheet, rather than the inconsistent impedance unit displayed on one product webpage, gives 20 mΩ at 100 kHz for this case size. The bank is modeled as 2000 µF with 10 mΩ ESR. The computed steady-state ripple current is at most 0.266 A RMS for the entire bank, well below the sum of the individual current ratings.

The nominal ESR-only switched results are 5.98-9.19 mV peak-to-peak. A separate stress calculation reduces capacitance to 1600 µF, raises bank ESR to 40 mΩ, and includes 10 nH of bank/interconnect ESL. The largest harmonic-model output ripple becomes 40.55 mV peak-to-peak, still below 100 mV.

$$Z_{Co}(j\omega)=r_o+j\omega L_{\mathrm{ESL},o}+\frac{1}{j\omega C_o}$$

The 40 mΩ cold ESR assumption is a sensitivity value. The Panasonic table specifies a larger impedance at -10 °C, but does not supply a guaranteed -20 °C limit for the chosen part in the retrieved document. Thus the stress calculation is evidence of margin under an explicit bound, not manufacturer certification at every temperature. The actual -20 °C impedance must be confirmed before a hardware-level guarantee is made. The 25 V voltage rating exceeds both the normal 14 V output and the allowed 16.8 V load-transient limit.


## 7. Input filter and input-capacitor current

The buck input current is approximately the output-inductor current while the MOSFET is ON and zero while it is OFF. The ideal source, however, is connected before Lf. The local capacitor supplies most of this pulsating current; the source supplies its average plus a much smaller residual ripple.

$$i_{\mathrm{buck}}(t)=q(t)i_L(t),\qquad I_{\mathrm{buck,av}}\simeq DI_o$$

To derive the approximate capacitor RMS current, first neglect the small triangular variation in iL. During ON time the capacitor current is -(1-D)Io; during OFF time it is DIo. Square these two values, weight them by their duty fractions, and add:

$$I_{Cf,\mathrm{rms}}^2\simeq D[(1-D)I_o]^2+(1-D)(DI_o)^2=I_o^2D(1-D)$$

Restoring the inductor ripple adds its ON-interval mean-square contribution:

$$I_{Cf,\mathrm{rms}}^2\simeq I_o^2D(1-D)+\frac{D\Delta I_L^2}{12}$$

The largest estimate is 4.40 A RMS for the bank, before accounting for the small current diverted through the damping branch. This current cannot be assigned to one ordinary small electrolytic capacitor. Instead, use ten parallel 2.2 µF / 100 V WIMA MKP4 polypropylene capacitors, giving 22 µF. Their individual calculated RMS current is approximately 0.44 A. The selected 2.2 µF construction is MKP4D042205I00JSSD, with ±5% capacitance tolerance; the source datasheet’s ordering system identifies the suffixes [6].

Use two 10 µF / 100 V MKP4 capacitors for the 20 µF damping branch, in series with 1.5 Ω. A 5 W Vishay AC05-class wirewound resistor is specified, with adequate pulse capability; the exact ordering suffix must match the 1.5 Ω and mounting option. Its normal calculated dissipation is below 0.07 W. A transient pulse-energy check is also required, as discussed in Section 13.

The input bank experiences approximately 0.30 V RMS AC in nominal full-load cases, or 0.326 V RMS in the stress case. For a 2.2 µF unit this corresponds to only about 0.45 A RMS. This operating point lies below the WIMA general AC-voltage guide when extended in its current-limited region. The guide is not a guaranteed scalar ripple-current rating at 100 kHz. The thermal estimate assumes a bank ESR of 5 mΩ, equivalent to 50 mΩ per parallel unit; at 0.44 A each, that represents less than 10 mW per part. Confirm actual impedance and heating when selecting the final production parts.

The capacitor voltage varies approximately linearly as the bank charges and discharges. Integrating the ON-interval current gives the first-order bus-voltage ripple:

$$\Delta V_{b,\mathrm{pp}}\simeq\frac{I_oD(1-D)}{C_ff_s}$$

The input inductor integrates this approximately triangular bus-voltage ripple. The area between adjacent zero crossings of that triangle gives the useful design estimate below. It is an estimate for sizing, whereas the final source-current ripple is obtained from the complete model.

$$\Delta I_{s,\mathrm{pp}}\simeq\frac{\Delta V_{b,\mathrm{pp}}}{8L_ff_s}=\frac{I_oD(1-D)}{8L_fC_ff_s^2}$$

With Lf = 48.4 µH and Cf = 22 µF, the nominal switched source ripple at the four operating corners is at most 25.29 mA. The harmonic stress model, including 5 nH input-bank/interconnect ESL, reaches 28.70 mA at those corners. Because D(1-D) is largest near D = 0.5, an interior input voltage can produce more ripple. An additional 100-case harmonic scan, using 25 input voltages and both load endpoints in nominal and stress conditions, finds a largest source ripple of 29.61 mA at 29.5 V and 125 W. This remains below 50 mA. The 100 V film-capacitor rating also accommodates the input-filter overshoot during the 44 V event.


## 8. Filter damping and harmonic ripple calculation

An undamped input LC network can amplify disturbances near resonance. In addition, a regulated converter can behave approximately as a constant-power input at low frequency: input current is Pin/Vin, so its incremental input resistance is negative. This is why an input filter must be included in the control analysis.

$$i_{\mathrm{in}}\simeq\frac{P_{\mathrm{in}}}{v_{\mathrm{in}}},\qquad r_{\mathrm{in,inc}}=\left(\frac{di_{\mathrm{in}}}{dv_{\mathrm{in}}}\right)^{-1}\simeq-\frac{V_{\mathrm{in}}^2}{P_{\mathrm{in}}}$$

The series Rd-Cd branch dissipates oscillatory energy while drawing no steady DC current. It is connected in parallel with the main input capacitor, not in series with the normal load current. This avoids the large DC efficiency penalty of placing a damping resistor in the main power path.

$$Z_f=r_{Cf}+sL_{\mathrm{ESL},f}+\frac{1}{sC_f},\quad Z_d=R_d+sL_{\mathrm{ESL},d}+\frac{1}{sC_d}$$

$$Z_p=(Z_f^{-1}+Z_d^{-1})^{-1},\quad Z_s=r_f+sL_f,\quad H_i(s)=\frac{Z_p}{Z_s+Z_p}$$

Hi is the transfer function from a perturbation of the buck’s local current demand to the source-current perturbation, with the ideal source voltage held fixed. It is derived by current division between Zp and Zs. The sign of the bus-voltage perturbation is negative when the local current demand increases.

For an independent ripple calculation, expand the local current in a Fourier series. Let τ = t/Ts, kn = j2πn, and approximate the ON-state current as Imin + ΔILτ/D for 0 ≤ τ &lt; D. Integrate the constant and linear terms separately:

$$J_n=\int_0^D\left(I_{\min}+\frac{\Delta I_L}{D}\tau\right)e^{-k_n\tau}d\tau$$

$$J_n=I_{\min}\frac{1-e^{-k_nD}}{k_n}+\frac{\Delta I_L}{D}\left[\frac{1-e^{-k_nD}}{k_n^2}-\frac{De^{-k_nD}}{k_n}\right]$$

$$I_{s,n}=H_i(jn\omega_s)J_n,\qquad V_{b,n}=-\frac{Z_pZ_s}{Z_p+Z_s}J_n$$

The output-inductor current is triangular over the complete cycle. Integrating its derivative and then dividing by kn gives its nonzero harmonic coefficients. The output voltage follows by multiplying by the parallel combination of output-capacitor impedance and load resistance:

$$I_{L,n}=\frac{\Delta I_L(1-e^{-k_nD})}{k_n^2D(1-D)},\qquad V_{o,n}=\frac{Z_{Co}}{1+Z_{Co}/R}I_{L,n}$$

$$x_{\mathrm{ac}}(\tau)=2\mathrm{Re}\sum_{n=1}^{N_h}X_ne^{j2\pi n\tau},\qquad X_{\mathrm{rms}}=\sqrt{2\sum_{n=1}^{N_h}|X_n|^2}$$

The supplied code uses 256 harmonics and 4096 phase samples. Raising the harmonic count from 256 to 512 changes the worst-case source ripple by about 0.0012 mA and the corresponding output ripple by about 0.047 mV. The calculation assumes lumped ESL; it does not predict PCB transmission-line ringing or radiated EMI. The steady switched calculation includes ESR but not ESL, so the two ripple results are deliberately labeled separately.

Figure 3. Steady switched-model ripple at the four line/load corners. These traces include ESR. The separate harmonic stress results include ESL and increased ESR.


## 9. Complete state-space model with capacitor ESR

Use the five physical energy-storage states below. Capacitor states are the voltages across their ideal capacitance, not their external terminal voltages. The PI integrator is added as a sixth state in the closed loop.

$$x_p=[i_f,\ v_{Cf},\ v_{Cd},\ i_L,\ v_{Co}]^T$$

At the input node, Kirchhoff’s current law states that input-inductor current minus switch current equals the sum of the two capacitor-branch currents. Ohm’s law across the branch resistances then gives an algebraic equation for vb:

$$i_f-qi_L=\frac{v_b-v_{Cf}}{r_{Cf}}+\frac{v_b-v_{Cd}}{R_d}$$

$$v_b(q)=\frac{i_f-qi_L+v_{Cf}/r_{Cf}+v_{Cd}/R_d}{1/r_{Cf}+1/R_d}$$

At the output node, capacitor terminal voltage equals the ideal capacitor voltage plus its ESR drop. Substitute iCo = iL - vo/R and solve for vo:

$$v_o=v_{Co}+r_o\left(i_L-\frac{v_o}{R}\right)\quad\Longrightarrow\quad v_o=\frac{v_{Co}+r_oi_L}{1+r_o/R}$$

The physical state derivatives follow directly from inductor voltage and capacitor current laws:

$$\frac{di_f}{dt}=\frac{V_g-r_fi_f-v_b}{L_f},\qquad \frac{dv_{Cf}}{dt}=\frac{v_b-v_{Cf}}{r_{Cf}C_f}$$

$$\frac{dv_{Cd}}{dt}=\frac{v_b-v_{Cd}}{R_dC_d}$$

$$\frac{di_L}{dt}=\frac{q(v_b-R_Qi_L)-(1-q)V_F-r_Li_L-v_o}{L}$$

$$\frac{dv_{Co}}{dt}=\frac{i_L-v_o/R}{C_o}$$

The ON and OFF vector fields are affine linear in the physical states for a fixed load. Denote them by fON and fOFF. Average the vector fields using the duty fractions:

$$\dot x_p=Df_{\mathrm{ON}}(x_p)+(1-D)f_{\mathrm{OFF}}(x_p)$$

This averaging order matters. Because vb(q) contains q through the capacitor ESR, replacing q by D inside every product would introduce D²iL terms and would incorrectly average qvb. The implementation evaluates each physical switch position first and then takes their weighted average.

During a held, inhibited-input event, positive output current eventually reaches zero and the freewheel diode blocks. The model then uses a DCM condition. During the return edge of a short pulse, however, the filtered input can fall below the charged output. The MOSFET body diode can then carry negative iL from the output back into the input filter. The additional hybrid return-edge model includes this path; it does not incorrectly apply the freewheel-diode zero-current clamp to both diode directions.


## 10. Feedback controller and its physical meaning

A cascade structure is used because it separates fast current regulation from slower voltage regulation. First define the voltage error. The PI output is a desired inductor current, not a duty ratio. Its integral state z has units of amperes:

$$e=V_{\mathrm{ref}}-v_o,\quad i_{\mathrm{ref,raw}}=K_pe+z,\quad \dot z=K_ie$$

$$C_v(s)=\frac{i_{\mathrm{ref}}(s)}{e(s)}=K_p+\frac{K_i}{s}=2.5+\frac{1250}{s}\quad[\mathrm{A/V}]$$

The proportional term reacts immediately to voltage error. The integral term accumulates any remaining error until the average output voltage reaches the reference. There is no need for a measured load resistance or a precomputed load-current lookup table.

The current error is multiplied by Kc = 2 Ω. That converts an error in amperes to a corrective voltage. Add the measured output voltage and the nominal diode drop, then divide by the source-voltage scaling to produce duty:

$$D_{\mathrm{raw}}=\frac{v_o+V_F+K_c(i_{\mathrm{ref}}-i_L)}{V_g+V_F},\qquad K_c=2\ \Omega$$

For intuition, temporarily neglect the input-filter drop and substitute this control law into the averaged inductor equation. The vo and VF terms approximately cancel the corresponding plant terms. What remains is an approximately first-order current loop:

$$L\dot i_L\simeq K_c(i_{\mathrm{ref}}-i_L)-(r_L+DR_Q)i_L$$

$$\frac{i_L(s)}{i_{\mathrm{ref}}(s)}\simeq\frac{K_c}{Ls+K_c+r_L+DR_Q}$$

Its pole frequency is approximately (Kc + rL + DRQ)/(2πL), or 3.3 kHz. The approximation is used only to choose gains; the final stability calculation includes the input filter and all ESR terms.

The controller limits the current reference to 0-10 A and the duty ratio to 0-0.9. Integrator back-calculation prevents the voltage PI from accumulating a large state while the current reference is clipped:

$$i_{\mathrm{ref}}=\mathrm{clip}(i_{\mathrm{ref,raw}},0,10),\qquad D=\mathrm{clip}(D_{\mathrm{raw}},0,0.9)$$

$$\dot z=K_ie+K_{\mathrm{aw}}(i_{\mathrm{ref}}-i_{\mathrm{ref,raw}}),\qquad K_{\mathrm{aw}}=2000\ \mathrm{s}^{-1}$$

If duty saturation is active and the error would push farther into saturation, the error-integration term is suspended; the back-calculation term remains. These limits and anti-windup rules are explicit in the code. The 10 A reference limit is not a guaranteed hardware peak-current limit: switching ripple and sensing delay must be included when implementing a separate protection comparator.


## 11. Gain selection, linearization, and sampled stability

If the current loop is fast, iL approximately follows iref. Ignoring ESR for this gain-selection step gives Co dvo/dt = iref - vo/R. Substituting the outer PI law and differentiating once yields the closed-loop characteristic polynomial:

$$C_os^2+(K_p+1/R)s+K_i=0$$

$$\omega_n=\sqrt{\frac{K_i}{C_o}},\qquad \zeta=\frac{K_p+1/R}{2\sqrt{C_oK_i}}$$

For Co = 0.002 F, Kp = 2.5 A/V, and Ki = 1250 A/(V s), the nominal natural frequency is 125.8 Hz. The approximate damping ratio ranges from 0.871 at light load to 0.992 at full load. This choice is well below the approximately 3.3 kHz current-loop bandwidth. These values are engineering selections justified by pole placement; they are not claimed to be a globally optimal numerical tuning.

For the actual stability check, append z to the physical states and evaluate the Jacobian at every operating point. A negative real part for every eigenvalue is the continuous-time local stability criterion:

$$A_{\mathrm{cl}}=\left.\frac{\partial f_{\mathrm{cl}}}{\partial x}\right|_{x_0},\qquad \mathrm{Re}\{\lambda_j(A_{\mathrm{cl}})\}<0$$

The code computes the Jacobian with complex-step differentiation. Perturb one state by jh, evaluate the analytic unsaturated equations, and divide the imaginary part by h. This avoids subtraction cancellation from finite differences. Saturation logic is excluded only for this local interior-point derivative; it is retained in the nonlinear transient simulations.

$$\frac{\partial f}{\partial x_j}\simeq\frac{\mathrm{Im}\{f(x+jh e_j)\}}{h},\qquad h=10^{-20}$$

A continuous-time check alone does not establish digital stability. Linearize the physical plant with duty held constant and discretize it exactly using a zero-order hold:

$$A_d=e^{A_pT_s},\qquad B_d=\int_0^{T_s}e^{A_p\tau}B_p\,d\tau$$

The augmented sampled state consists of the five physical states, the voltage-integrator state, and the previously computed duty. The update law deliberately includes a full-cycle computation/PWM delay:

$$x_{p,k+1}=A_dx_{p,k}+B_dd_{k-1}$$

$$z_{k+1}=z_k-K_iT_sC_yx_{p,k},\qquad d_k=K_xx_{p,k}+K_zz_k$$

$$\rho(M)=\max_j|\lambda_j(M)|<1$$

| Vg / Po | Continuous max Re(λ) | Sampled ρ(M) | Outer PM |
| --- | --- | --- | --- |
| 24 V / 50 W | -694.0 s⁻¹ | 0.993129 | 71.89° |
| 24 V / 125 W | -792.0 s⁻¹ | 0.992163 | 79.96° |
| 36 V / 50 W | -694.7 s⁻¹ | 0.993121 | 72.27° |
| 36 V / 125 W | -791.8 s⁻¹ | 0.992164 | 80.28° |

The phase margin in the table belongs to the continuous outer loop with the inner loop closed. It is not mislabeled as the margin of the delayed digital loop. Digital delay is assessed by the augmented sampled eigenvalues and by switched trajectories. A finite frequency search did not find a -180° outer-loop phase crossing; the resulting infinite gain-margin entry in the CSV is only a property of that analyzed frequency range and model.

Figure 4. Continuous outer-loop return ratio with the current loop closed, at the four operating corners. Crossover is approximately 201-208 Hz and phase margin is 71.9-80.3°.

An additional 208-point line/load grid spans 24-36 V and 50-125 W. Tolerance checks include 512 combinations formed from 128 grouped parameter vertices at four line/load corners, plus 500 seeded interior combinations. The largest real continuous pole among these 1012 cases is -544.07 s⁻¹ and the largest sampled spectral radius is 0.994600. These finite sweeps provide numerical evidence over the stated ranges; they are not a formal interval proof for every possible simultaneous parameter value.

| Parameter | Analyzed range |
| --- | --- |
| Output and input inductance | ±5% independently |
| Output capacitance | ±20% |
| Input / damping capacitance | ±10%; grouped at vertices, independent in interior sampling |
| Output-bank ESR | 5-40 mΩ |
| Input-bank ESR | 2.5-10 mΩ |
| Damping resistance | 1.35-1.65 Ω |


## 12. Semiconductor selection and loss calculation

Select STP110N10F7 for the high-side switch [2]. The TO-220 device is rated at 100 V with a 175 °C maximum junction temperature and a 1.0 °C/W junction-to-case resistance. The datasheet gives a 7 mΩ maximum on-resistance at 25 °C and 10 V gate drive. The design model doubles that resistance to 14 mΩ as a hot-resistance allowance. The nominal switching-time data are 36 ns rise and 21 ns fall, with 25 ns turn-on delay and 52 ns turn-off delay.

The MOSFET conducts only during its ON interval. Assuming small ripple, its RMS-current-squared contribution is D times the complete inductor mean square. Multiplying by hot on-resistance gives conduction loss:

$$P_{Q,\mathrm{cond}}=R_QD\left(I_o^2+\frac{\Delta I_L^2}{12}\right)$$

During a switching transition, approximate simultaneous drain voltage and current as linearly overlapping. Integrating the triangular instantaneous power gives one half of VI multiplied by transition duration. Add the ON and OFF contributions and multiply by switching frequency:

$$E_{\mathrm{sw}}\simeq\frac{1}{2}V_bI_o(t_r+t_f),\qquad P_{Q,\mathrm{sw}}=E_{\mathrm{sw}}f_s$$

Gate delay does not itself imply a simultaneous VI overlap interval. Its effect on timing can be represented by a duty offset and delay; adding the full datasheet gate delays to the overlap time would count intervals during which the MOSFET may still be fully OFF or ON. The digital verification already includes a substantially larger full-cycle delay. To test switching-loss uncertainty, a separate sensitivity case doubles tr + tf.

The model also budgets output-capacitance charging loss and gate-drive power. An equivalent 1.5 nF output capacitance is an engineering allowance above the datasheet’s 992 pF point value at 50 V; it is not a guaranteed constant capacitance. Likewise, 100 nC is used as a gate-charge budget above the 72 nC typical value. These are explicit loss assumptions, with remaining driver consumption covered by the auxiliary budget.

$$P_{C_{\mathrm{oss}}}\simeq\frac{1}{2}C_{\mathrm{oss,eq}}V_b^2f_s,\qquad P_{\mathrm{gate}}=Q_gV_{\mathrm{gate}}f_s$$

Select STPS20100CT for the freewheel diode [3], with its two anodes connected together and its common cathode at the switch node. The package provides two 10 A, 100 V Schottky diodes. Its effective junction-to-case resistance for both junctions sharing the load is approximately 0.9 °C/W. At full load the package-average freewheel current is at most 5.24 A, about 2.62 A per junction under symmetric sharing.

$$I_{D,\mathrm{av}}=(1-D)I_o,\qquad P_{D,\mathrm{cond}}\simeq V_F(1-D)I_o$$

A constant 1.0 V diode drop is used in the main electrical and loss models. This is conservative relative to the retrieved room-temperature forward-drop data at the relevant current, while 1.1 V is tested as a cold/uncertainty sensitivity. A separate 0.2 W leakage allowance is included. The latter is an engineering budget, not a guaranteed leakage bound at every junction temperature; unusually high leakage must be checked against the actual purchased device. Diode switching loss is neglected as expressly allowed by the assignment.


## 13. Efficiency and heatsink design

Total loss includes semiconductor conduction and switching, MOSFET output-capacitance charging, gate charge, both winding losses, capacitor ESR loss, core loss, and explicit allowances. The constant auxiliary allowance is 0.5 W, the diode leakage allowance is 0.2 W, and damping-branch loss is conservatively budgeted at 0.15 W. The source current used for input winding loss is DIo; this approximation is adequate for that small loss term, but it is not the method used to estimate efficiency.

$$P_{\mathrm{loss}}=P_{Q,\mathrm{cond}}+P_{Q,\mathrm{sw}}+P_{C_{\mathrm{oss}}}+P_{\mathrm{gate}}+P_D+P_{\mathrm{Cu}}+P_{\mathrm{cap}}+P_{\mathrm{core,tot}}+P_{\mathrm{allow}}$$

$$P_{\mathrm{in}}=P_o+P_{\mathrm{loss}},\qquad \eta=\frac{P_o}{P_o+P_{\mathrm{loss}}}$$

| Vg / Po | Total loss | Estimated η | Tj MOS / diode |
| --- | --- | --- | --- |
| 24 V / 50 W | 3.228 W | 93.94% | 52.9 / 61.6 °C |
| 24 V / 125 W | 8.707 W | 93.49% | 59.7 / 76.1 °C |
| 36 V / 50 W | 3.975 W | 92.63% | 53.9 / 66.6 °C |
| 36 V / 125 W | 9.948 W | 92.63% | 60.7 / 89.1 °C |

The smallest efficiency estimate on the 208-point operating grid is 92.63%. Doubling the MOSFET switching-overlap time and increasing the diode drop to 1.1 V produces a smallest corner estimate of 91.66%. This sensitivity result supports some loss margin; it does not bound every possible combination of gate-drive, diode, magnetic, and layout uncertainties.

Use one separate Fischer SK 129 50.8 STS heatsink per device [7], with nominal natural-convection thermal resistance 5.3 °C/W. Assume an electrically insulating mounting interface no worse than 1.0 °C/W. Keep the two heatsinks thermally independent in the model; if they are mounted inside a small shared enclosure, their local ambient temperature must be reassessed.

$$T_j=T_a+P_{\mathrm{device}}(R_{\theta JC}+R_{\theta CS}+R_{\theta SA})$$

The acceptable thermal design target is Tj ≤ 175 - 25 = 150 °C. Solving the preceding equation for the largest allowable heatsink resistance gives a selection rule before a part is chosen:

$$R_{\theta SA}\leq\frac{150-T_a}{P_{\mathrm{device}}}-R_{\theta JC}-R_{\theta CS}$$

The worst nominal diode dissipation, including the leakage allowance, is 5.43 W. At 50 °C ambient the selected heatsink predicts a diode junction temperature of 89.13 °C. The largest MOSFET dissipation is 1.47 W and its predicted junction temperature is 60.73 °C. Both remain well below the 150 °C design target. The extra 50 °C ambient assumption is more demanding than the separate 40 °C heatsink note in the assignment.

Figure 5. Estimated efficiency across the specified line/load grid and sampled stability results for the 1012 tolerance cases. All shown sampled radii are below one.


## 14. Load-step validation and interpretation

The most direct transient validation is to step the physical resistance between 3.920 Ω and 1.568 Ω in both directions. The controller is updated every 10 µs, uses saturated commands and anti-windup, and applies the previously computed duty for the next switching cycle. Each ON and OFF interval is propagated using its exact affine state transition, rather than a coarse fixed-step approximation.

| Input | Load step | Output min / max | 1% settling |
| --- | --- | --- | --- |
| 24 V | 50 to 125 W | 12.708 / 14.006 V | 5.95 ms |
| 24 V | 125 to 50 W | 13.994 / 15.418 V | 5.44 ms |
| 36 V | 50 to 125 W | 12.711 / 14.009 V | 5.91 ms |
| 36 V | 125 to 50 W | 13.993 / 15.417 V | 5.43 ms |

The load-step envelope is 12.708-15.418 V. These values lie inside the required 11.2-16.8 V range. The output settles within ±1% in approximately 5.43-5.95 ms in the nominal switched cases. The assignment does not specify a settling-time limit; it is reported to characterize the design rather than presented as a supplied requirement.

An additional 32 averaged transient cases combine output-inductor tolerance, output-capacitance tolerance, low/high ESR, both input endpoints, and both load-step directions. Their output-voltage envelope is 12.646-15.488 V. This separate sweep is labeled averaged: it is not misrepresented as 32 switched-model runs.

The initial physical cause of the voltage dip is a temporary current deficit. The output capacitor supplies the new load current before the inductor current rises. On load release, the excess inductor current charges the capacitor and produces an overshoot. Their signs follow directly from the capacitor-current equation:

$$\Delta v_C(t)=\frac{1}{C_o}\int_0^t\left[i_L(\tau)-i_{\mathrm{load}}(\tau)\right]d\tau$$

The voltage PI changes the requested current; the inner loop then changes the inductor voltage through the duty ratio. The integral term restores the average output voltage after the short current mismatch. The output-capacitor ESR also creates an immediate terminal-voltage change at the resistance step, which the terminal-voltage algebraic equation includes.

Figure 6. Switched load-step responses. Dashed red lines show the required transient voltage limits. The four cases cover both endpoint input voltages and both directions of the largest specified resistance step.


## 15. Survival of the 44 V input event

A filter can overshoot above the applied source voltage when the input changes abruptly. It is therefore insufficient to compare a component’s rating only with 44 V. The verification starts from an established operating point, changes the ideal source to 44 V, and disables the high-side MOSFET for the whole pulse. The overvoltage decision is a latched Vg &gt; 40 V inhibit. Restart requires a valid input and controlled reset; uninterrupted regulation during the pulse is not claimed.

The source is the assignment’s ideal voltage source and may absorb energy returned by the input filter. That assumption is relevant because the calculated input-inductor current briefly becomes negative as the filter rings. An actual source unable to absorb returned energy would require a different clamp or protection analysis.

The first plotted surge case starts at 24 V and 125 W, with +10% filter capacitance and +5% input inductance. Thirty-two held-pulse cases vary initial source voltage, initial load, filter capacitance, input inductance, and damping resistance. A linear filter scan additionally covers 80 pulse widths from 1 µs to 1 ms at these 32 conditions, giving 2560 cases. A further 128 hybrid cases check 50, 100, 134, and 200 µs pulse widths, including both edges and the MOSFET body diode. The largest values across the held and hybrid cases are:

| Quantity | Largest simulated value | Design comparison |
| --- | --- | --- |
| Filtered input-bus voltage | 58.976 V | 100 V input film capacitors |
| Input-inductor current magnitude | 26.683 A | Input-core flux 0.245 T |
| Output-core initial flux | 0.234 T in surge model | Normal ripple / load-step checks reach 0.256 T |
| MOSFET blocked voltage | about 60.0 V including diode drop | 100 V rating; fast layout ringing not modeled |

The input-inductor flux uses the actual tolerance-adjusted inductance and minimum core area. Negative input-inductor current is larger during some short-pulse return edges than during a held 1 ms event. When vb falls below vo minus the assumed 1 V MOSFET body-diode drop, the additional model connects the switch node to vb + 1 V and permits negative output-inductor current. The computed peak body-diode current is about 5.03 A. This is a short transient, not a reverse current through the freewheel Schottky diode. Output regulation during the inhibited interval is not required.

$$L\dot i_L=v_b+V_{\mathrm{body}}-r_Li_L-v_o\quad\mathrm{during\ MOSFET\ body\ diode\ conduction}$$

The input filter is initially energized, as it would be during a disturbance to a running converter. A source turn-on from zero volts, precharge hardware, repetitive surge intervals, protection-circuit propagation delay, and automatic restart have not been qualified. The latched inhibit is part of the paper design; its physical comparator and gate-driver implementation remains outside the assignment’s gate-drive scope.

The damping resistor is checked by integrating iCd²Rd over the complete pulse and return [8]. The largest calculated energy is 0.0234 J and the largest instantaneous power is approximately 200 W. A single-pulse energy acceptance threshold of at least 0.1 J gives margin. The AC05 curve at 1.5 Ω lies above this threshold for short adiabatic pulses; use the actual resistance and ordering variant when checking the curve. Its 5 W continuous rating alone would not establish this result. Repetitive pulse heating is outside the specified single-event case.

Figure 7. 44 V input pulse with the high-side switch inhibited. The filter overshoot, reversing source current, and both core fluxes are shown. The plotted case has increased input-filter L and C.

Figure 8. Selected worst return-edge hybrid case. The source returns to its initial voltage after a short 44 V pulse while switching remains inhibited. Negative output-inductor current flows through the MOSFET body diode when the input bus undershoots. The input-core flux remains below 0.3 T with the revised 32-turn winding.


## 16. Numerical implementation and how to run the MATLAB solution

The main deliverable is matlab/buck622.m. It is a function file with local helper functions and requires only base MATLAB functions. It does not require Simulink, the Control System Toolbox, or the Optimization Toolbox. Its input-pulse checks include the return-edge scan and the hybrid MOSFET body-diode cases. Place the current folder in the matlab directory and run the following command in the Command Window:

results = buck622;

To choose a results directory and suppress plotting, run:

results = buck622('my_results', false);

The code exports CSV tables, four figures, and a MAT-file containing parameters and results. It also contains assertions for nominal efficiency, output ripple, source ripple, load-step bounds, junction-temperature margin, sampled/continuous tolerance stability, and surge flux. An assertion failure after parameter changes should be investigated, not removed to make the script finish.

The averaged equations are used to locate operating points and compute Jacobians. For the switched model, each switch position is represented as dx/dt = Aq x + bq. Its exact interval solution is:

$$x(t+h)=e^{A_qh}x(t)+\int_0^he^{A_q\tau}b_q\,d\tau$$

The implementation evaluates the equivalent equilibrium-shift form. Diagonalizing each constant interval matrix once allows efficient repeated propagation for the varying ON duration. This is valid for the fixed resistance within each load interval; the cache is rebuilt when the resistance changes.

$$x(t+h)=x_{\mathrm{eq},q}+e^{A_qh}\left[x(t)-x_{\mathrm{eq},q}\right],\qquad x_{\mathrm{eq},q}=-A_q^{-1}b_q$$

In the executed Python reference, exact interval propagation was independently compared with a tightly toleranced ODE solver at each corner. The largest physical-state discrepancy was approximately 10⁻¹¹ in the corresponding SI state units. Equilibrium residuals were below 6 × 10⁻⁸ SI derivative units. These checks assess the numerical implementation of the equations; they do not validate a real component model.

The MATLAB file was parsed with tree-sitter-matlab and produced no syntax error nodes. MATLAB and Octave were unavailable in the execution environment, so a successful MATLAB runtime execution cannot be claimed. Every reported numerical value was generated by the included Python/NumPy/SciPy implementation of the same equations. This distinction is recorded in the source, summary JSON, and README.

The seeded interior tolerance samples may differ between MATLAB and NumPy because random-stream initialization can differ. The deterministic grouped-vertex cases, physical equations, and nominal scenario definitions are shared. No claim is made that a given random row is identical between interpreters.

| File / directory | Purpose |
| --- | --- |
| matlab/buck622.m | Self-contained MATLAB design, simulation, metrics, and plots |
| validation/ | Executed Python reference; PDF build script |
| results/ | CSV tables, model parameters, and verification summary |
| figures/ | Scientific plots and exact circuit/control diagrams |
| datasheets/ | Source manufacturer documents, including two mirrored originals |
| report_source/ | Editable English source and equation images |


## 17. What has and has not been established

The selected circuit meets the assignment’s electrical limits in the stated numerical models and tested parameter sets. Its reference voltage is ideal, so the steady-state result does not include reference tolerance, sensing offset, ADC quantization, or current-sensor error. The calculated static mean error is below 0.034%; a hardware error budget would still need to fit inside the remaining ±3% allowance.

The cold-ESR and ESL values are declared design assumptions, not retrieved guaranteed bounds at every operating temperature. The WIMA high-frequency ripple check uses its published general guide and an explicit ESR heating allowance; a guaranteed high-frequency current limit for the final part should be obtained if this paper design is turned into hardware. Magnetic loss uses the simplified fit allowed by the assignment, without a detailed fringing or proximity-field calculation.

The nominal efficiency result includes estimated losses rather than measured input/output power. Switching times are typical datasheet values under the manufacturer’s test conditions and depend on the real gate driver and layout. The doubled-switching-time sensitivity remains above 90%, but cannot replace gate-waveform measurement. The 44 V survival result depends on timely switching inhibit and the ideal source’s ability to absorb returned filter energy.

No full-system interval proof, EMI-compliance test, hardware prototype, or actual MATLAB/Octave runtime execution has been performed. The delivered files make the mathematical design and its numerical evidence inspectable, and retain the limitations needed to interpret those results correctly.


## References and supplied component documents

[1] MIT OpenCourseWare. 6.622 Power Electronics, Spring 2023, Design Project. User-supplied assignment, mit6_622_s23_designproj.pdf.

https://ocw.mit.edu

[2] STMicroelectronics. STF110N10F7 / STP110N10F7 datasheet, DocID024058 Rev 2, July 2013. Tables 2-6 and thermal / resistance curves.

https://www.st.com/resource/en/datasheet/stp110n10f7.pdf

[3] STMicroelectronics. STPS20100CT datasheet, Ed. 2C, August 2002. Dual Schottky ratings, forward drop, and coupled thermal model.

https://www.st.com/resource/en/datasheet/stps20100.pdf

[4] Ferroxcube. RM14/I cores and accessories, 1 September 2004. Geometry, AL, winding area, bobbin and mounting data. Manufacturer-authored original retrieved from an independent mirror; custom AL targets in this solution are not standard catalog selections.

https://download.ferrite.de/pdf/rm14i.pdf

[5] Panasonic Industry. FR-A series aluminum electrolytic capacitor datasheet, 1 September 2025. EEUFR1E102: 1000 µF, 25 V, 20 mΩ at 100 kHz and 20 °C, 2.18 A RMS ripple rating.

https://industrial.panasonic.com/cdbs/www-data/pdf/RDF0000/ABA0000C1259.pdf

[6] WIMA. MKP 4 polypropylene capacitor datasheet, March 2026. Nominal values, construction dimensions, ordering system, impedance curves and general permissible AC-voltage guide.

https://www.wima.de/wp-content/uploads/media/e_WIMA_MKP_4.pdf

[7] Fischer Elektronik. SK 129 50.8 STS product datasheet, manufacturer page captured 9 January 2023; 5.3 K/W thermal resistance. Manufacturer-authored page retrieved from a mirror.

https://static.chipdip.ru/lib/410/DOC046410519.pdf

[8] Vishay Draloric. AC, AC-AT, AC-NI wirewound resistor datasheet, document 28730. Select AC05 class, 1.5 Ω, 5 W; confirm pulse acceptance for the final ordering variant.

https://www.vishay.com/docs/28730/ac_ac-at_ac-ni.pdf

Datasheets are supplied as source documents. Their manufacturers retain the corresponding rights. The numerical derivations and proposed component targets in this report are the worked solution, not statements issued by those manufacturers.
