function results = buck622(outdir, makeplots)
% BUCK622  MIT 6.622 design project: 14 V, 50-125 W asynchronous buck.
% Usage: results = buck622;   or   results = buck622('my_results',false);
% Base MATLAB only. No Simulink, Control System, or Optimization toolbox.
% Equations and assumptions are explained in the accompanying English report.
% Numerical results supplied with this package were independently evaluated in
% Python. This MATLAB source has NOT been executed in MATLAB/Octave by its author.
% The switched model includes capacitor ESR, one-cycle controller delay, and
% exact ON/OFF propagation. ESL is assessed separately by harmonic analysis.

if nargin < 1, outdir = fullfile(pwd,'buck622_results'); end
if nargin < 2, makeplots = true; end
if ~exist(outdir,'dir'), mkdir(outdir); end
p = parameters();
corners = [24 50;24 125;36 50;36 125];
fprintf('14 V BUCK DESIGN, fs = %.0f kHz\n',p.fs/1e3);
static = zeros(4,16); linear = zeros(4,7); switched = cell(4,1);
for k = 1:4
    vg=corners(k,1); power=corners(k,2); R=p.V^2/power;
    [x,d] = operating_point(p,vg,R);
    a = analytic_metrics(p,vg,power,1);
    st = stability(p,vg,R);
    sw = switching_case(p,vg,power,power,0.020,0.030);
    switched{k}=sw;
    n = sw.t >= 0.0298;
    static(k,:)=[vg power d a.deltaI a.Imin a.Imax a.eta a.Ploss ...
        a.Pmos a.Pdiode a.Tmos a.Tdiode ...
        max(sw.vo(n))-min(sw.vo(n)) ...
        max(sw.x(n,1))-min(sw.x(n,1)) ...
        trapz(sw.t(n),sw.vo(n))/(sw.t(find(n,1,'last'))-sw.t(find(n,1))) max(abs(eig(st.A)))];
    linear(k,:)=[vg power max(real(eig(st.A))) st.rho st.fc st.pm st.gm];
    fprintf('Vin=%g V, P=%g W: eta=%.2f%%, ripple=%.2f mV, input=%.2f mA\n',...
        vg,power,100*a.eta,1e3*static(k,13),1e3*static(k,14));
end
writecsv(fullfile(outdir,'corner_results.csv'),...
    'Vin_V,P_W,D,IL_pp_A,IL_min_A,IL_max_A,efficiency,loss_W,MOS_W,diode_W,Tj_MOS_C,Tj_diode_C,Vo_pp_V,Is_pp_A,Vo_mean_V,max_abs_pole',static);
writecsv(fullfile(outdir,'stability_corners.csv'),...
    'Vin_V,P_W,max_real_pole_1_s,sampled_spectral_radius,outer_fc_Hz,outer_PM_deg,outer_GM_dB',linear);

% Both load-step directions at each endpoint of the normal input range.
loadcases=cell(4,1); loadstats=zeros(4,7);
for k=1:4
    vg=corners(k,1);
    if mod(k,2)==1, a=50; b=125; else, a=125; b=50; end
    sw=switching_case(p,vg,a,b,0.010,0.030);
    loadcases{k}=sw; n=sw.t>=0.010;
    loadstats(k,:)=[vg a b min(sw.vo(n)) max(sw.vo(n)) ...
        max(sw.x(n,4)) settling(sw.t(n)-0.010,sw.vo(n),p.V,0.01)];
end
writecsv(fullfile(outdir,'load_steps.csv'),...
    'Vin_V,P_before_W,P_after_W,Vo_min_V,Vo_max_V,IL_peak_A,settling_1pct_s',loadstats);

% Averaged continuous-input/load grid and deterministic tolerance coverage.
grid=zeros(13*16,5); k=0;
for vg=linspace(24,36,13)
    for power=linspace(50,125,16)
        k=k+1; a=analytic_metrics(p,vg,power,1);
        s=stability(p,vg,p.V^2/power,false);
        grid(k,:)=[vg power a.eta max(real(eig(s.A))) s.rho];
    end
end
writecsv(fullfile(outdir,'operating_grid.csv'),...
    'Vin_V,P_W,efficiency,max_real_pole_1_s,sampled_spectral_radius',grid);
tol=tolerance_sweep(p);
writecsv(fullfile(outdir,'tolerance_stability.csv'),...
    'case,Vin_V,P_W,L_H,Lf_H,C_F,Cf_F,Cd_F,ESRo_ohm,ESRf_ohm,Rd_ohm,max_real_pole_1_s,sampled_spectral_radius',tol);

% 44 V surge: switch inhibited during pulse, as permitted by the assignment.
surge=surge_test(p);
writecsv(fullfile(outdir,'surge_waveforms.csv'),...
    'time_s,Vsource_V,If_A,Vbus_V,IL_A,Vo_V,Binput_T,Boutput_T',surge);
ret=surge_return_tests(p);
writecsv(fullfile(outdir,'surge_return_linear_scan.csv'),...
    'C_sign,Lf_sign,Rd_sign,Vin_initial_V,P_initial_W,pulse_width_s,If_abs_peak_A,Binput_abs_peak_T',ret.linear);
writecsv(fullfile(outdir,'surge_return_hybrid.csv'),...
    'C_sign,Lf_sign,Rd_sign,Vin_initial_V,P_initial_W,pulse_width_s,If_abs_peak_A,Binput_abs_peak_T,Boutput_abs_peak_T,Vbus_max_V,Vbus_min_V,Rd_peak_W,body_diode_peak_A,Rd_energy_J',ret.hybrid);
writecsv(fullfile(outdir,'surge_return_worst_waveform.csv'),...
    'time_s,Vsource_V,Vbus_V,If_A,IL_A,Vo_V,Binput_T,Boutput_T,Icd_A',ret.wave);

% Nominal and pessimistic ESR/ESL harmonic ripple calculations.
harm=zeros(8,8);k=0;
for cold=[false true]
    pp=p;
    if cold, pp.ro=4*p.ro; pp.C=.8*p.C; pp.Cf=.9*p.Cf; pp.Lf=.95*p.Lf; end
    for j=1:4
        k=k+1; h=harmonic_ripple(pp,corners(j,1),corners(j,2),256);
        harm(k,:)=[cold corners(j,:) h.vo_pp h.is_pp h.Icf_rms h.Icd_rms h.Vbus_ac_rms];
    end
end
writecsv(fullfile(outdir,'harmonic_ripple.csv'),...
    'cold_stress,Vin_V,P_W,Vo_pp_with_ESL_V,Is_pp_with_ESL_A,Icf_rms_A,Icd_rms_A,Vbus_ac_rms_V',harm);
% The largest D(1-D), hence largest source ripple, can occur between input
% endpoints. Scan the full line range, not just the four operating corners.
hline=zeros(2*25*2,5);k=0;
for cold=[false true]
    pp=p;if cold,pp.ro=4*p.ro;pp.C=.8*p.C;pp.Cf=.9*p.Cf;pp.Lf=.95*p.Lf;end
    for vg=linspace(24,36,25)
        for W=[50 125]
            k=k+1;h=harmonic_ripple(pp,vg,W,256);
            hline(k,:)=[cold vg W h.vo_pp h.is_pp];
        end
    end
end
writecsv(fullfile(outdir,'harmonic_line_sweep.csv'),...
    'cold_stress,Vin_V,P_W,Vo_pp_with_ESL_V,Is_pp_with_ESL_A',hline);

% Explicit loss-model sensitivity: doubled switching time and higher diode Vf.
stress=zeros(4,4);
for k=1:4
    pp=p; pp.vd=1.1; a=analytic_metrics(pp,corners(k,1),corners(k,2),2);
    stress(k,:)=[corners(k,:) a.eta a.Ploss];
end
writecsv(fullfile(outdir,'loss_sensitivity.csv'),...
    'Vin_V,P_W,efficiency_2x_switching_1p1V_diode,loss_W',stress);

if makeplots
    plot_results(p,corners,switched,loadcases,linear,surge,outdir);
end
results=struct('parameters',p,'corners',static,'stability',linear,...
    'load_steps',loadstats,'operating_grid',grid,'tolerances',tol,...
    'harmonics',harm,'harmonic_line_sweep',hline,'loss_sensitivity',stress,'surge',surge,'surge_return',ret);
save(fullfile(outdir,'buck622_results.mat'),'results');
assert(all(static(:,7)>=.90),'Efficiency specification failed.');
assert(all(static(:,13)<=.100),'Switching output ripple failed.');
assert(all(static(:,14)<=.050),'Switching input ripple failed.');
assert(all(loadstats(:,4)>=11.2) && all(loadstats(:,5)<=16.8),'Load transient failed.');
assert(all(tol(:,12)<0) && all(tol(:,13)<1),'Tolerance stability failed.');
assert(all(static(:,11)<150) && all(static(:,12)<150),'Junction margin failed.');
assert(max(abs(surge(:,7)))<.3 && max(abs(surge(:,8)))<.3,'Surge core flux failed.');
assert(max(ret.hybrid(:,8))<.3 && max(ret.hybrid(:,9))<.3,'Return-edge core flux failed.');
assert(max(hline(:,4))<.1 && max(hline(:,5))<.05,'Line-sweep harmonic ripple failed.');
fprintf('Completed. Results written to %s\n',outdir);
end

function p=parameters()
p.V=14; p.fs=1e5; p.L=96.8e-6; p.Lf=48.4e-6;
p.C=2e-3; p.Cf=22e-6; p.Cd=20e-6;
p.ro=.010; p.rf=.005; p.rd=1.5;
p.rl=.020; p.rlf=.043; p.ron=.014; p.vd=1.0;
p.kc=2; p.kp=2.5; p.ki=1250; p.aw=2000;
p.ilim=10; p.dmax=.9; p.Ta=50;
p.tr=36e-9; p.tf=21e-9; p.Qg=100e-9; p.Vgate=10;
p.Coss=1500e-12; p.Rhs=5.3; p.Rcs=1.0;
p.Rjc_mos=1.0; p.Rjc_diode=.9;
p.N=22; p.Nf=32; p.AL=200e-9; p.ALf=48.4e-6/32^2;
p.Ae=198e-6; p.Amin=168e-6; p.Aw=112e-6; p.Vcore_cm3=13.9;
p.lesl_in=5e-9; p.lesl_out=10e-9; p.lesl_d=20e-9;
end

function [x,d]=operating_point(p,vg,R)
I=p.V/R; rb=1/(1/p.rf+1/p.rd);
f=@(d)d*(vg-p.rlf*d*I-(p.ron+rb*(1-d))*I)...
    -(1-d)*p.vd-p.rl*I-p.V;
d=fzero(f,[0 p.dmax]); ib=d*I; vb=vg-p.rlf*ib;
z=I+(d*(vg+p.vd)-p.V-p.vd)/p.kc;
x=[ib;vb;vb;I;p.V;z];
end

function [vb,vo,icf,icd]=nodes(x,p,R,q)
G=1/p.rf+1/p.rd;
vb=(x(1)-q*x(4)+x(2)/p.rf+x(3)/p.rd)/G;
vo=(x(5)+p.ro*x(4))/(1+p.ro/R);
icf=(vb-x(2))/p.rf; icd=(vb-x(3))/p.rd;
end

function f=phase_rhs(x,p,vg,R,q)
% This expression is used only with q=0 or q=1.
[vb,vo,icf,icd]=nodes(x,p,R,q);
f=[(vg-p.rlf*x(1)-vb)/p.Lf;icf/p.Cf;icd/p.Cd;...
    (q*(vb-p.ron*x(4))-(1-q)*p.vd-p.rl*x(4)-vo)/p.L;...
    (x(4)-vo/R)/p.C];
end

function f=plant(x,p,vg,R,d)
% Average the two vector fields, not an averaged product q*vb(q).
f=d*phase_rhs(x,p,vg,R,1)+(1-d)*phase_rhs(x,p,vg,R,0);
end

function [d,dz]=controller(x,p,vg,R,limited)
vo=(x(5)+p.ro*x(4))/(1+p.ro/R); e=p.V-vo;
iraw=p.kp*e+x(6); ir=iraw;
if limited, ir=min(max(ir,0),p.ilim); end
draw=(vo+p.vd+p.kc*(ir-x(4)))/(vg+p.vd);d=draw;
if limited, d=min(max(d,0),p.dmax); end
dz=p.ki*e+p.aw*(ir-iraw);
if limited && ((draw>p.dmax && e>0)||(draw<0 && e<0))
    dz=p.aw*(ir-iraw);
end
end

function f=closed_rhs(x,p,vg,R)
[d,dz]=controller(x,p,vg,R,false);
f=[plant(x(1:5),p,vg,R,d);dz];
end

function J=jacobian(fun,x)
h=1e-20; v=fun(x); J=zeros(numel(v),numel(x));
for k=1:numel(x)
    xx=complex(x);xx(k)=xx(k)+1i*h;J(:,k)=imag(fun(xx))/h;
end
end

function s=stability(p,vg,R,needmargin)
if nargin<4,needmargin=true;end
[x,d]=operating_point(p,vg,R);
A=jacobian(@(y)closed_rhs(y,p,vg,R),x);
Ap=jacobian(@(y)plant(y,p,vg,R,d),x(1:5));
Bp=phase_rhs(x(1:5),p,vg,R,1)-phase_rhs(x(1:5),p,vg,R,0);
Ky=jacobian(@(y)duty_unlimited(y,p,vg,R),x);
Cy=zeros(1,5);Cy(4)=p.ro/(1+p.ro/R);Cy(5)=1/(1+p.ro/R);
E=expm([Ap Bp;zeros(1,6)]/p.fs);Ad=E(1:5,1:5);Bd=E(1:5,6);
% State [power-stage states (5), voltage integrator, previous duty].
M=[Ad zeros(5,1) Bd;-p.ki/p.fs*Cy 1 0;Ky(1:5) Ky(6) 0];
s.A=A;s.rho=max(abs(eig(M)));s.M=M;s.fc=NaN;s.pm=NaN;s.gm=NaN;
if needmargin
    f=logspace(0,4.5,3000);[loop,~,~]=outer_loop(p,vg,R,f);
    [s.fc,s.pm,s.gm]=margins(f,loop);
end
end

function d=duty_unlimited(x,p,vg,R)
[d,~]=controller(x,p,vg,R,false);
end

function [loop,Ai,Bi]=outer_loop(p,vg,R,f)
[x,d]=operating_point(p,vg,R);
Ap=jacobian(@(y)plant(y,p,vg,R,d),x(1:5));
Bp=phase_rhs(x(1:5),p,vg,R,1)-phase_rhs(x(1:5),p,vg,R,0);
Cy=zeros(1,5);Cy(4)=p.ro/(1+p.ro/R);Cy(5)=1/(1+p.ro/R);
Kinner=Cy;Kinner(4)=Kinner(4)-p.kc;Kinner=Kinner/(vg+p.vd);
Ai=Ap+Bp*Kinner;Bi=Bp*p.kc/(vg+p.vd);
loop=zeros(size(f));
for k=1:numel(f)
    ss=1i*2*pi*f(k);H=Cy*((ss*eye(5)-Ai)\Bi);
    loop(k)=(p.kp+p.ki/ss)*H;
end
end

function [fc,pm,gm]=margins(f,L)
db=20*log10(abs(L));ph=unwrap(angle(L))*180/pi;lf=log10(f);
j=find(db(1:end-1)>=0 & db(2:end)<0);
fc=NaN;pm=NaN;gm=Inf;
for k=j(:)'
    a=-db(k)/(db(k+1)-db(k));pp=ph(k)+a*(ph(k+1)-ph(k));
    if isnan(pm)||180+pp<pm,pm=180+pp;fc=10^(lf(k)+a*(lf(k+1)-lf(k)));end
end
j=find(ph(1:end-1)>-180 & ph(2:end)<=-180);
for k=j(:)'
    a=(-180-ph(k))/(ph(k+1)-ph(k));gg=-(db(k)+a*(db(k+1)-db(k)));
    gm=min(gm,gg);
end
end

function a=analytic_metrics(p,vg,W,switch_factor)
R=p.V^2/W;[x,d]=operating_point(p,vg,R);I=p.V/R;
vb=vg-p.rlf*x(1);di=(p.V+p.vd+p.rl*I)*(1-d)/(p.L*p.fs);
Irms2=I^2+di^2/12;Iin=d*I;
Pcond=d*Irms2*p.ron;
Psw=.5*vb*I*(p.tr+p.tf)*p.fs*switch_factor;
Pcoss=.5*p.Coss*vb^2*p.fs;
Pgate=p.Qg*p.Vgate*p.fs;
Pdiode=p.vd*(1-d)*I;
Pcu=p.rl*Irms2+p.rlf*Iin^2;
Icin2=I^2*d*(1-d)+d*di^2/12;
Pcap=p.rf*Icin2+p.ro*di^2/12;
Bac=p.L*di/(2*p.N*p.Ae);
Pcore=1e-3*2.5e-4*p.fs^1.63*Bac^2.45*p.Vcore_cm3;
Paux=.5;Pleak=.2;Pdamp=.15;
Pmos=Pcond+Psw+Pcoss;
Ploss=Pmos+Pgate+Pdiode+Pcu+Pcap+2*Pcore+Paux+Pleak+Pdamp;
a=struct('D',d,'deltaI',di,'Imin',I-di/2,'Imax',I+di/2,...
    'eta',W/(W+Ploss),'Ploss',Ploss,'Pmos',Pmos,'Pdiode',Pdiode,...
    'Pcond',Pcond,'Psw',Psw,'Pcoss',Pcoss,'Pgate',Pgate,'Pcu',Pcu,...
    'Pcap',Pcap,'Pcore',Pcore,'Paux',Paux,'Pleak',Pleak,'Pdamp',Pdamp,...
    'Icin',sqrt(Icin2),'Icout',di/sqrt(12),'Bpk',p.L*(I+di/2)/(p.N*p.Amin),...
    'Tmos',p.Ta+Pmos*(p.Rjc_mos+p.Rcs+p.Rhs),...
    'Tdiode',p.Ta+(Pdiode+Pleak)*(p.Rjc_diode+p.Rcs+p.Rhs));
end

function c=phase_cache(p,vg,R,q)
fun=@(x)phase_rhs(x,p,vg,R,q);A=jacobian(fun,zeros(5,1));b=fun(zeros(5,1));
[V,D]=eig(A);c.V=V;c.lambda=diag(D);c.Vi=inv(V);c.xeq=-A\b;
end

function xx=propagate(c,x,t)
xx=real(c.V*(exp(c.lambda*t).*(c.Vi*(x-c.xeq)))+c.xeq);
end

function sw=switching_case(p,vg,Pa,Pb,tstep,tend)
Ts=1/p.fs;nc=round(tend/Ts);ns=12;
tt=zeros(nc*2*(ns+1),1);xx=zeros(numel(tt),5);vv=tt;dd=tt;
[x,dhold]=operating_point(p,vg,p.V^2/Pa);z=x(6);x=x(1:5);
Rold=NaN;ind=0;
for k=1:nc
    t0=(k-1)*Ts;W=Pa;if t0>=tstep-1e-12,W=Pb;end;R=p.V^2/W;
    if R~=Rold,c1=phase_cache(p,vg,R,1);c0=phase_cache(p,vg,R,0);Rold=R;end
    [dn,dz]=controller([x;z],p,vg,R,true);z=z+Ts*dz;
    dur=[dhold*Ts (1-dhold)*Ts];cs={c1,c0};qq=[1 0];base=t0;
    for m=1:2
        xstart=x;
        for j=0:ns
            h=dur(m)*j/ns;y=propagate(cs{m},xstart,h);
            ind=ind+1;tt(ind)=base+h;xx(ind,:)=y';
            [~,vv(ind)]=nodes(y,p,R,qq(m));dd(ind)=dhold;
        end
        x=propagate(cs{m},xstart,dur(m));base=base+dur(m);
    end
    dhold=dn;
end
sw=struct('t',tt,'x',xx,'vo',vv,'d',dd,'vg',vg,'Pa',Pa,'Pb',Pb);
end

function tol=tolerance_sweep(p)
% 128 deterministic vertices (seven independent groups), at four line/load
% corners. A further 500 seeded interior parameter combinations are included.
tol=zeros(4*128+500,13);k=0;corn=[24 50;24 125;36 50;36 125];
for bits=0:127
    s=2*bitget(bits,1:7)-1;pp=p;
    pp.L=p.L*(1+.05*s(1));pp.Lf=p.Lf*(1+.05*s(2));
    pp.C=p.C*(1+.2*s(3));pp.Cf=p.Cf*(1+.1*s(4));pp.Cd=p.Cd*(1+.1*s(4));
    pp.ro=p.ro*(2.25+1.75*s(5));pp.rf=p.rf*(1.25+.75*s(6));pp.rd=p.rd*(1+.1*s(7));
    for j=1:4
        k=k+1;s=stability(pp,corn(j,1),p.V^2/corn(j,2),false);
        tol(k,:)=[k corn(j,:) pp.L pp.Lf pp.C pp.Cf pp.Cd pp.ro pp.rf pp.rd max(real(eig(s.A))) s.rho];
    end
end
rng(622,'twister');
for j=1:500
    u=rand(1,11);pp=p;
    pp.L=p.L*(.95+.1*u(1));pp.Lf=p.Lf*(.95+.1*u(2));pp.C=p.C*(.8+.4*u(3));
    pp.Cf=p.Cf*(.9+.2*u(4));pp.Cd=p.Cd*(.9+.2*u(5));pp.ro=p.ro*(.5+3.5*u(6));
    pp.rf=p.rf*(.5+1.5*u(7));pp.rd=p.rd*(.9+.2*u(8));vg=24+12*u(9);W=50+75*u(10);
    k=k+1;s=stability(pp,vg,p.V^2/W,false);
    tol(k,:)=[k vg W pp.L pp.Lf pp.C pp.Cf pp.Cd pp.ro pp.rf pp.rd max(real(eig(s.A))) s.rho];
end
end

function h=harmonic_ripple(p,vg,W,N)
a=analytic_metrics(p,vg,W,1);D=a.D;di=a.deltaI;I=p.V/(p.V^2/W);
n=(1:N)';kk=1i*2*pi*n;w=2*pi*p.fs*n;
J=(I-di/2)*(1-exp(-kk*D))./kk + di/D*((1-exp(-kk*D))./(kk.^2)-D*exp(-kk*D)./kk);
Zf=p.rf+1i*w*p.lesl_in+1./(1i*w*p.Cf);
Zd=p.rd+1i*w*p.lesl_d+1./(1i*w*p.Cd);Zp=1./(1./Zf+1./Zd);
Zs=p.rlf+1i*w*p.Lf;Is=J.*Zp./(Zs+Zp);Vb=-J.*(Zp.*Zs)./(Zp+Zs);
Icf=Vb./Zf;Icd=Vb./Zd;
IL=di*(1-exp(-kk*D))./(kk.^2*D*(1-D));
Zo=p.ro+1i*w*p.lesl_out+1./(1i*w*p.C);R=p.V^2/W;
Vo=IL.*Zo./(1+Zo/R);
theta=(0:4095)/4096;
is=real(2*(Is.'*exp(kk*theta)));vo=real(2*(Vo.'*exp(kk*theta)));
h=struct('vo_pp',max(vo)-min(vo),'is_pp',max(is)-min(is),...
    'Icf_rms',sqrt(2*sum(abs(Icf).^2)),'Icd_rms',sqrt(2*sum(abs(Icd).^2)),...
    'Vbus_ac_rms',sqrt(2*sum(abs(Vb).^2)));
end

function s=surge_test(p)
% Worst lower-end initial line, maximum load, +C and +Lf stress. The input
% ideal voltage source is allowed to absorb the returning filter energy.
pp=p;pp.Cf=1.1*p.Cf;pp.Cd=1.1*p.Cd;pp.Lf=1.05*p.Lf;
vg0=24;R=p.V^2/125;[x,~]=operating_point(pp,vg0,R);x=x(1:5);
dt=.2e-6;t=(0:dt:.001)';s=zeros(numel(t),8);
for k=1:numel(t)
    [vb,vo]=nodes(x,pp,R,0);
    s(k,:)=[t(k) 44 x(1) vb x(4) vo pp.Lf*x(1)/(p.Nf*p.Amin) pp.L*x(4)/(p.N*p.Amin)];
    f=@(y)off_dcm_rhs(y,pp,44,R);
    a=f(x);b=f(x+dt*a/2);c=f(x+dt*b/2);d=f(x+dt*c);
    x=x+dt*(a+2*b+2*c+d)/6;x(4)=max(x(4),0);
end
end

function f=off_dcm_rhs(x,p,vg,R)
f=phase_rhs(x,p,vg,R,0);if x(4)<=0&&f(4)<0,f(4)=0;end
end

function ret=surge_return_tests(p)
% The inhibit remains latched after return. The source may absorb energy.
% Linear input-filter scan: 80 pulse widths from 1 us to 1 ms, 32 corners.
% Hybrid return checks: 50,100,134,200 us; includes MOSFET body-diode current.
lin=zeros(8*4*80,8);hy=zeros(8*4*4,14);nl=0;nh=0;worst=0;wave=[];
corn=[24 50;24 125;36 50;36 125];
for bits=0:7
    sg=2*bitget(bits,1:3)-1;pp=p;
    pp.Cf=p.Cf*(1+.1*sg(1));pp.Cd=p.Cd*(1+.1*sg(1));
    pp.Lf=p.Lf*(1+.05*sg(2));pp.rd=p.rd*(1+.1*sg(3));
    Af=jacobian(@(y)phase_rhs(y,pp,44,p.V^2/125,0),zeros(5,1));Af=Af(1:3,1:3);
    [V,D]=eig(Af);la=diag(D);Vi=inv(V);
    for j=1:4
        vg=corn(j,1);W=corn(j,2);R=p.V^2/W;[x,~]=operating_point(pp,vg,R);
        for width=logspace(-6,-3,80)
            a=filter_many(V,Vi,la,x(1:3),44,linspace(0,width,200));
            b=filter_many(V,Vi,la,a(:,end),vg,linspace(0,.0012,400));
            im=max([abs(a(1,:)) abs(b(1,:))]);B=pp.Lf*im/(pp.Nf*pp.Amin);
            nl=nl+1;lin(nl,:)=[sg vg W width im B];
        end
        for width=[50 100 134 200]*1e-6
            [stats,ww]=inhibited_hybrid(pp,vg,W,width);
            nh=nh+1;hy(nh,:)=[sg vg W width stats];
            if stats(2)>worst,worst=stats(2);wave=ww;end
        end
    end
end
ret=struct('linear',lin,'hybrid',hy,'wave',wave);
end

function y=filter_many(V,Vi,la,x,vg,t)
eq=[0;vg;vg];y=real(bsxfun(@plus,V*bsxfun(@times,exp(la*t),Vi*(x-eq)),eq));
end

function [stats,wave]=inhibited_hybrid(p,vg0,W,width)
R=p.V^2/W;[x,~]=operating_point(p,vg0,R);x=x(1:5);
dt=.5e-6;n=round((width+.0012)/dt);stats=[0 0 0 0 Inf 0 0 0];
wave=zeros(floor(n/4)+1,9);nw=0;
for k=0:n
    t=k*dt;vg=vg0;if t<width-1e-12,vg=44;end
    [a,q]=inhibited_rhs(x,p,vg,R);[vb,vo,~,icd]=nodes(x,p,R,q);
    Bi=p.Lf*x(1)/(p.Nf*p.Amin);Bo=p.L*x(4)/(p.N*p.Amin);
    stats(1)=max(stats(1),abs(x(1)));stats(2)=max(stats(2),abs(Bi));
    stats(3)=max(stats(3),abs(Bo));stats(4)=max(stats(4),vb);stats(5)=min(stats(5),vb);
    stats(6)=max(stats(6),p.rd*icd^2);stats(7)=max(stats(7),max(-x(4),0));
    stats(8)=stats(8)+p.rd*icd^2*dt;
    if mod(k,4)==0,nw=nw+1;wave(nw,:)=[t vg vb x(1) x(4) vo Bi Bo icd];end
    old=x(4);b=inhibited_rhs(x+dt*a/2,p,vg,R);
    c=inhibited_rhs(x+dt*b/2,p,vg,R);d=inhibited_rhs(x+dt*c,p,vg,R);
    x=x+dt*(a+2*b+2*c+d)/6;if old*x(4)<0,x(4)=0;end
end
wave=wave(1:nw,:);
end

function [f,q]=inhibited_rhs(x,p,vg,R)
[vb,vo]=nodes(x,p,R,0);
if x(4)<-1e-10 || (x(4)<=1e-10 && vo>vb+1.0)
    q=1;f=phase_rhs(x,p,vg,R,1);[vb,vo]=nodes(x,p,R,1);
    f(4)=(vb+1.0-p.rl*x(4)-vo)/p.L;
else
    q=0;f=phase_rhs(x,p,vg,R,0);if x(4)<=0&&f(4)<0,f(4)=0;end
end
end

function t=settling(time,y,target,tol)
j=find(abs(y-target)>tol*target,1,'last');
if isempty(j),t=0;elseif j==numel(y),t=NaN;else,t=time(j+1);end
end

function writecsv(path,header,A)
fid=fopen(path,'w');assert(fid>=0,'Cannot create output CSV.');
fprintf(fid,'%s\n',header);fclose(fid);dlmwrite(path,A,'-append','precision','%.12g');
end

function plot_results(p,corners,steady,steps,linear,surge,outdir)
set(0,'DefaultAxesFontName','Times New Roman','DefaultAxesFontSize',12);
set(0,'DefaultTextFontName','Times New Roman','DefaultTextFontSize',12);
f=figure('Color','w');
for k=1:4
    subplot(2,2,k);s=steps{k};plot(1e3*s.t,s.vo,'LineWidth',1);hold on;
    plot([0 30],[11.2 11.2],'r--',[0 30],[16.8 16.8],'r--');grid on;
    xlabel('Time (ms)');ylabel('Output voltage (V)');
    title(sprintf('%g V: %g to %g W',s.vg,s.Pa,s.Pb));
end
print(f,fullfile(outdir,'load_steps.png'),'-dpng','-r180');
f=figure('Color','w');
for k=1:4
    s=steady{k};n=s.t>.02995;
    subplot(2,1,1);plot((s.t(n)-.02995)*1e6,1e3*(s.vo(n)-mean(s.vo(n))));hold on;
    subplot(2,1,2);plot((s.t(n)-.02995)*1e6,1e3*(s.x(n,1)-mean(s.x(n,1))));hold on;
end
subplot(2,1,1);grid on;ylabel('Output AC (mV)');
subplot(2,1,2);grid on;ylabel('Source current AC (mA)');xlabel('Time (us)');
print(f,fullfile(outdir,'switching_ripple.png'),'-dpng','-r180');
f=figure('Color','w');ff=logspace(0,4.5,1000);
for k=1:4
    loop=outer_loop(p,corners(k,1),p.V^2/corners(k,2),ff);
    subplot(2,1,1);semilogx(ff,20*log10(abs(loop)));hold on;
    subplot(2,1,2);semilogx(ff,unwrap(angle(loop))*180/pi);hold on;
end
subplot(2,1,1);grid on;ylabel('Outer-loop gain (dB)');
subplot(2,1,2);grid on;ylabel('Phase (deg)');xlabel('Frequency (Hz)');
print(f,fullfile(outdir,'outer_loop_bode.png'),'-dpng','-r180');
f=figure('Color','w');
subplot(3,1,1);plot(surge(:,1)*1e3,surge(:,4));ylabel('Input bus (V)');grid on;
subplot(3,1,2);plot(surge(:,1)*1e3,surge(:,3));ylabel('Source current (A)');grid on;
subplot(3,1,3);plot(surge(:,1)*1e3,surge(:,7:8));ylabel('Core flux (T)');xlabel('Time (ms)');grid on;
print(f,fullfile(outdir,'input_surge.png'),'-dpng','-r180');
end
